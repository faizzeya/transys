/* Summarizer — one-click summaries with your own OpenAI API key.
   Everything runs in the browser; the key is stored in localStorage only. */
(() => {
  "use strict";

  const MODES = [
    { id: "tldr",      label: "TL;DR",          prompt: "Write a TL;DR: the core message in 1–3 plain sentences." },
    { id: "bullets",   label: "Bullet points",  prompt: "Summarize as concise bullet points covering every main idea, in order." },
    { id: "keypoints", label: "Key takeaways",  prompt: "List the most important takeaways and insights, each one a short bullet starting with a bold keyword." },
    { id: "exec",      label: "Executive",      prompt: "Write an executive summary with these sections: Overview, Key Points, Implications, Recommended Actions. Use short headings and bullets." },
    { id: "actions",   label: "Action items",   prompt: "Extract every action item, decision, deadline and owner mentioned. Format as a checklist ('- [ ] ...'). If none exist, say so briefly and give a one-line summary instead." },
    { id: "simple",    label: "Explain simply", prompt: "Explain the text in simple language a 12-year-old could follow, using short sentences." },
    { id: "outline",   label: "Outline",        prompt: "Produce a hierarchical outline of the text's structure with headings and nested bullets." },
    { id: "qa",        label: "Q&A",            prompt: "Summarize as 4–8 question-and-answer pairs that cover what a reader most needs to know." },
  ];
  const LENGTH = {
    short:  "Keep it very brief — roughly 50–80 words.",
    medium: "Aim for roughly 120–200 words.",
    long:   "Be thorough — roughly 300–450 words, without padding.",
  };
  const MAX_CHARS = 400000; // ~100k tokens; guards against accidental giant pastes

  const $ = (id) => document.getElementById(id);
  const store = {
    get(k, d) { try { const v = localStorage.getItem("summarizer." + k); return v === null ? d : JSON.parse(v); } catch { return d; } },
    set(k, v) { try { localStorage.setItem("summarizer." + k, JSON.stringify(v)); } catch {} },
    del(k)    { try { localStorage.removeItem("summarizer." + k); } catch {} },
  };

  let mode = store.get("mode", "bullets");
  let lastSummary = "";
  let busy = false;

  /* ---------- Theme ---------- */
  const applyTheme = (t) => { if (t) document.documentElement.dataset.theme = t; else delete document.documentElement.dataset.theme; };
  applyTheme(store.get("theme", null));
  $("themeBtn").onclick = () => {
    const dark = document.documentElement.dataset.theme
      ? document.documentElement.dataset.theme === "dark"
      : matchMedia("(prefers-color-scheme: dark)").matches;
    const next = dark ? "light" : "dark";
    applyTheme(next); store.set("theme", next);
  };

  /* ---------- Modes ---------- */
  const modesEl = $("modes");
  MODES.forEach((m) => {
    const b = document.createElement("button");
    b.className = "mode" + (m.id === mode ? " active" : "");
    b.textContent = m.label;
    b.dataset.id = m.id;
    b.title = "Summarize as: " + m.label;
    b.onclick = () => {
      mode = m.id; store.set("mode", mode);
      modesEl.querySelectorAll(".mode").forEach((x) => x.classList.toggle("active", x.dataset.id === mode));
      if ($("input").value.trim()) summarize(); // one click = summary
    };
    modesEl.appendChild(b);
  });

  /* ---------- Options persistence ---------- */
  ["length", "language"].forEach((id) => {
    const el = $(id); el.value = store.get(id, el.value);
    el.onchange = () => store.set(id, el.value);
  });

  /* ---------- Input helpers ---------- */
  const input = $("input");
  input.value = store.get("draft", "");
  const updateCount = () => {
    const words = input.value.trim() ? input.value.trim().split(/\s+/).length : 0;
    $("wordCount").textContent = words.toLocaleString() + (words === 1 ? " word" : " words");
  };
  input.addEventListener("input", () => { updateCount(); store.set("draft", input.value); });
  updateCount();

  $("clearBtn").onclick = () => { input.value = ""; store.set("draft", ""); updateCount(); input.focus(); };
  $("pasteBtn").onclick = async () => {
    try { input.value = await navigator.clipboard.readText(); input.dispatchEvent(new Event("input")); }
    catch { setStatus("Clipboard access was blocked — press Ctrl+V in the text box instead.", true); }
  };
  $("fileBtn").onclick = () => $("fileInput").click();
  $("fileInput").onchange = async (e) => {
    const f = e.target.files[0]; if (!f) return;
    input.value = await f.text(); input.dispatchEvent(new Event("input"));
    setStatus(`Loaded ${f.name}`); e.target.value = "";
  };
  input.addEventListener("dragover", (e) => e.preventDefault());
  input.addEventListener("drop", async (e) => {
    const f = e.dataTransfer.files[0]; if (!f) return;
    e.preventDefault(); input.value = await f.text(); input.dispatchEvent(new Event("input"));
  });

  /* ---------- Settings ---------- */
  const dlg = $("settings");
  const openSettings = () => {
    $("apiKey").value = store.get("apiKey", "");
    $("model").value = store.get("model", "gpt-4o-mini");
    $("saveHistory").checked = store.get("saveHistory", true);
    $("testResult").textContent = "";
    dlg.showModal();
  };
  $("settingsBtn").onclick = openSettings;
  $("saveSettingsBtn").onclick = () => {
    store.set("apiKey", $("apiKey").value.trim());
    store.set("model", $("model").value.trim() || "gpt-4o-mini");
    store.set("saveHistory", $("saveHistory").checked);
    setStatus("Settings saved.");
  };
  $("forgetKeyBtn").onclick = () => { store.del("apiKey"); $("apiKey").value = ""; $("testResult").textContent = "Key removed from this browser."; };
  $("testKeyBtn").onclick = async () => {
    const key = $("apiKey").value.trim();
    if (!key) { $("testResult").textContent = "Enter a key first."; return; }
    $("testResult").textContent = "Testing…";
    try {
      const r = await fetch("https://api.openai.com/v1/models", { headers: { Authorization: "Bearer " + key } });
      $("testResult").textContent = r.ok ? "✓ Key works." : "✗ " + (await errorText(r));
    } catch { $("testResult").textContent = "✗ Network error — check your connection."; }
  };

  /* ---------- Summarize ---------- */
  function buildMessages(text) {
    const m = MODES.find((x) => x.id === mode) || MODES[1];
    const lang = $("language").value;
    const system = [
      "You are an expert summarizer. Summarize faithfully: never invent facts, numbers or names that are not in the text.",
      m.prompt,
      LENGTH[$("length").value],
      lang === "same" ? "Write in the same language as the input text." : `Write the summary in ${lang}.`,
      "Use Markdown (headings, bullets, bold) where it helps. Output only the summary, with no preamble.",
    ].join("\n");
    return [
      { role: "system", content: system },
      { role: "user", content: "Text to summarize:\n\"\"\"\n" + text + "\n\"\"\"" },
    ];
  }

  async function summarize() {
    if (busy) return;
    const text = input.value.trim();
    if (!text) { setStatus("Paste some text first.", true); input.focus(); return; }
    if (text.length > MAX_CHARS) { setStatus(`Text is too long (${text.length.toLocaleString()} chars). Limit is ${MAX_CHARS.toLocaleString()}.`, true); return; }
    const key = store.get("apiKey", "");
    if (!key) { setStatus("Add your OpenAI API key in Settings to start.", true); openSettings(); return; }

    busy = true; $("summarizeBtn").disabled = true;
    const out = $("output");
    out.classList.remove("empty"); out.innerHTML = "";
    setStatus('<span class="spinner"></span>Summarizing…', false, true);
    lastSummary = "";

    try {
      const r = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: "Bearer " + key },
        body: JSON.stringify({ model: store.get("model", "gpt-4o-mini"), messages: buildMessages(text), stream: true, temperature: 0.3 }),
      });
      if (!r.ok) throw new Error(await errorText(r));

      // Stream tokens as they arrive
      const reader = r.body.getReader(); const dec = new TextDecoder(); let buf = "";
      while (true) {
        const { done, value } = await reader.read(); if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split("\n"); buf = lines.pop();
        for (const line of lines) {
          const l = line.trim();
          if (!l.startsWith("data:")) continue;
          const data = l.slice(5).trim();
          if (data === "[DONE]") continue;
          try {
            const delta = JSON.parse(data).choices?.[0]?.delta?.content;
            if (delta) { lastSummary += delta; out.innerHTML = renderMarkdown(lastSummary); }
          } catch { /* partial JSON line, ignore */ }
        }
      }
      if (!lastSummary) throw new Error("The model returned an empty response.");
      const words = lastSummary.trim().split(/\s+/).length;
      const inWords = text.split(/\s+/).length;
      setStatus(`Done · ${words} words (${Math.max(1, Math.round((words / inWords) * 100))}% of original)`);
      $("copyBtn").disabled = $("downloadBtn").disabled = false;
      addHistory(text, lastSummary);
    } catch (err) {
      out.classList.add("empty"); out.textContent = "Your summary will appear here.";
      setStatus(err.message || "Something went wrong.", true);
    } finally {
      busy = false; $("summarizeBtn").disabled = false;
    }
  }

  async function errorText(r) {
    let msg = `HTTP ${r.status}`;
    try { const j = await r.json(); if (j.error?.message) msg = j.error.message; } catch {}
    if (r.status === 401) return "Invalid API key. Check it in Settings.";
    if (r.status === 429) return "Rate limit or quota reached on your OpenAI account. " + msg;
    return msg;
  }

  function setStatus(msg, isError = false, html = false) {
    const s = $("status"); s.classList.toggle("error", isError);
    if (html) s.innerHTML = msg; else s.textContent = msg;
  }

  $("summarizeBtn").onclick = summarize;
  document.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "Enter") { e.preventDefault(); summarize(); }
  });

  /* ---------- Output actions ---------- */
  $("copyBtn").onclick = async () => {
    try { await navigator.clipboard.writeText(lastSummary); setStatus("Copied to clipboard."); }
    catch { setStatus("Copy blocked by the browser — select the text and press Ctrl+C.", true); }
  };
  $("downloadBtn").onclick = () => {
    const blob = new Blob([lastSummary], { type: "text/plain;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `summary-${new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-")}.txt`;
    a.click(); URL.revokeObjectURL(a.href);
  };

  /* ---------- History ---------- */
  function addHistory(text, summary) {
    if (!store.get("saveHistory", true)) return;
    const h = store.get("history", []);
    h.unshift({ t: Date.now(), mode, preview: text.slice(0, 90), text: text.slice(0, 20000), summary });
    store.set("history", h.slice(0, 25)); renderHistory();
  }
  function renderHistory() {
    const h = store.get("history", []); const ul = $("historyList"); ul.innerHTML = "";
    $("histCount").textContent = h.length ? `(${h.length})` : "";
    h.forEach((item) => {
      const li = document.createElement("li");
      const label = (MODES.find((m) => m.id === item.mode) || {}).label || item.mode;
      li.innerHTML = `<small>${new Date(item.t).toLocaleString()} · ${escapeHtml(label)}</small>${escapeHtml(item.preview)}…`;
      li.onclick = () => {
        input.value = item.text; input.dispatchEvent(new Event("input"));
        lastSummary = item.summary; $("output").classList.remove("empty");
        $("output").innerHTML = renderMarkdown(item.summary);
        $("copyBtn").disabled = $("downloadBtn").disabled = false;
      };
      ul.appendChild(li);
    });
  }
  $("clearHistBtn").onclick = () => { store.set("history", []); renderHistory(); };
  renderHistory();

  /* ---------- Tiny safe Markdown renderer ---------- */
  function escapeHtml(s) { return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }
  function inline(s) {
    return escapeHtml(s)
      .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
      .replace(/(^|[^*])\*(?!\s)(.+?)\*/g, "$1<em>$2</em>")
      .replace(/`(.+?)`/g, "<code>$1</code>");
  }
  function renderMarkdown(md) {
    const lines = md.split("\n"); let html = ""; let list = null;
    const close = () => { if (list) { html += `</${list}>`; list = null; } };
    for (const raw of lines) {
      const line = raw.replace(/\s+$/, "");
      let m;
      if (!line.trim()) { close(); continue; }
      if ((m = line.match(/^#{1,6}\s+(.*)/))) { close(); html += `<h3>${inline(m[1])}</h3>`; continue; }
      if ((m = line.match(/^\s*[-*•]\s+\[( |x|X)\]\s+(.*)/))) {
        if (list !== "ul") { close(); html += "<ul>"; list = "ul"; }
        html += `<li>${m[1].trim() ? "☑" : "☐"} ${inline(m[2])}</li>`; continue;
      }
      if ((m = line.match(/^\s*[-*•]\s+(.*)/))) { if (list !== "ul") { close(); html += "<ul>"; list = "ul"; } html += `<li>${inline(m[1])}</li>`; continue; }
      if ((m = line.match(/^\s*\d+[.)]\s+(.*)/))) { if (list !== "ol") { close(); html += "<ol>"; list = "ol"; } html += `<li>${inline(m[1])}</li>`; continue; }
      close(); html += `<p>${inline(line)}</p>`;
    }
    close(); return html;
  }

  if (!store.get("apiKey", "")) setStatus("Tip: open Settings and add your OpenAI API key to get started.");
})();
