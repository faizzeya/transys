# Summarizer

One-click summaries of your text — no prompts to write. Bring your own OpenAI API key.

## Quick start
1. Unzip `Summarizer.zip`.
2. Double-click **`index.html`** — it opens in your browser (Chrome, Edge, Firefox, Safari). No install, no server.
3. Click **⚙ Settings**, paste your OpenAI API key (`sk-...`), optionally click **Test key**, then **Save**.
4. Paste text and click any style button — the summary streams in immediately.

## Summary styles
| Button | What you get |
|---|---|
| TL;DR | The core message in 1–3 sentences |
| Bullet points | Every main idea as concise bullets |
| Key takeaways | The most important insights |
| Executive | Overview, Key Points, Implications, Recommended Actions |
| Action items | Checklist of tasks, decisions, deadlines and owners |
| Explain simply | Plain-language explanation |
| Outline | Hierarchical structure of the text |
| Q&A | Question-and-answer pairs |

Also: Short / Medium / Detailed length, output language (same as input, English, Urdu, Arabic, and more), open or drag-and-drop `.txt`/`.md` files, copy, download as `.txt`, local history of the last 25 summaries, light/dark theme, and **Ctrl+Enter** to summarize.

## Privacy
- Your API key is saved only in this browser's local storage and is sent only to `api.openai.com`.
- Text goes straight from your browser to OpenAI; there is no middle server.
- Use **Forget key** in Settings to remove it, and **Clear history** to wipe saved summaries.

## Model & cost
Default model is `gpt-4o-mini` (fast and inexpensive). You can type any chat model your account can use in Settings. Usage is billed to your own OpenAI account.

## Troubleshooting
- **Invalid API key** — re-copy the key from platform.openai.com/api-keys.
- **Rate limit / quota** — your OpenAI account needs credit or has hit its limit.
- **Paste button blocked** — some browsers block clipboard reading from local files; just press Ctrl+V in the box.

## Files
- `index.html` — the app
- `style.css` — styling (light/dark)
- `app.js` — logic, OpenAI streaming call, Markdown rendering

© Transys. All rights reserved.
