SNOOKER PRO 1.0  -  Freeware
Developed by Transys, Pakistan.  CEO Faiz ul Haque Zeya
=============================

A full-size snooker game for Windows: 15 reds + 6 colours, six pockets, spin physics,
official scoring and fouls, and a computer opponent with three skill levels.

REQUIREMENTS
  Windows 10 / 11 (64-bit). No installation, no extra files. Just run SnookerPro.exe.

MODES
  1  Play vs Computer - Easy
  2  Play vs Computer - Medium
  3  Play vs Computer - Hard
  4  Two players on the same computer

CONTROLS
  Mouse ............ aim the cue
  Shift + mouse .... fine aim          Left/Right arrows: nudge aim (Ctrl = finer)
  Hold Left button
  or Space ......... charge power; release to shoot (Right click cancels)
  Spin ball ........ drag the red dot (top = follow, bottom = screw back, sides = side spin)
  A ................ aim guide: off / line / full      X: centre the spin
  S ................ sound on/off     H: help     C: concede frame     Esc: menu
  Cue ball in hand . click inside the D (semicircle) to place it

RULES (summary)
  Pot a red (1), then a colour (yellow 2, green 3, brown 4, blue 5, pink 6, black 7).
  Colours go back on their spots while reds remain. After the last red, pot the colours
  in order from yellow to black. Foul = at least 4 points to the opponent (more if a
  higher-value ball is involved): potting the cue ball, hitting no ball, hitting the wrong
  ball first, potting a wrong ball. If the cue ball is potted the opponent places it in the D.

NOT INCLUDED IN THIS VERSION
  Free ball after a snooker, replay-after-foul requests, re-rack options.

Windows SmartScreen may warn about unknown publishers for any new unsigned program;
choose "More info" > "Run anyway".
