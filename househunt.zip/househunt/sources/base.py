"""Shared HTTP layer: polite rate-limited fetching, disk cache, optional real-browser mode."""
from __future__ import annotations

import hashlib
import json
import time
from typing import Optional

import requests

from config import CACHE_DIR, CACHE_TTL_SEC, HTTP_TIMEOUT, REQUEST_DELAY_SEC, USER_AGENT


class BlockedError(RuntimeError):
    """The site refused the request (HTTP 403/429 or a bot-check page)."""


_last_request: dict[str, float] = {}
_session = requests.Session()
_session.headers.update({
    "User-Agent": USER_AGENT,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
})

_BOT_MARKERS = ("px-captcha", "perimeterx", "press & hold", "are you a human", "captcha-delivery",
                "cf-chl", "access to this page has been denied")


def _cache_path(url: str):
    return CACHE_DIR / (hashlib.sha1(url.encode()).hexdigest() + ".json")


def _cache_get(url: str) -> Optional[str]:
    p = _cache_path(url)
    if p.exists():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            if time.time() - data["ts"] < CACHE_TTL_SEC:
                return data["html"]
        except Exception:
            pass
    return None


def _cache_put(url: str, html: str) -> None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    _cache_path(url).write_text(json.dumps({"ts": time.time(), "url": url, "html": html}), encoding="utf-8")


def _throttle(host: str) -> None:
    wait = REQUEST_DELAY_SEC - (time.time() - _last_request.get(host, 0))
    if wait > 0:
        time.sleep(wait)
    _last_request[host] = time.time()


def fetch_html(url: str, mode: str = "requests", use_cache: bool = True,
               extra_headers: Optional[dict] = None) -> str:
    """mode = 'requests' (fast, plain HTTP), 'browser' (headless Chromium via Playwright) or
    'browser-visible' (a real Chromium window on your screen). Raises BlockedError when refused."""
    if use_cache:
        cached = _cache_get(url)
        if cached is not None:
            return cached
    host = url.split("/")[2]
    _throttle(host)

    if mode.startswith("browser"):
        html = _fetch_with_browser(url, visible=(mode == "browser-visible"))
    else:
        r = _session.get(url, timeout=HTTP_TIMEOUT, headers=extra_headers or {})
        if r.status_code in (403, 429):
            raise BlockedError(f"{host} returned HTTP {r.status_code}")
        r.raise_for_status()
        html = r.text

    low = html[:20000].lower()
    if any(m in low for m in _BOT_MARKERS) and "<article" not in low and "__next_data__" not in low:
        raise BlockedError(f"{host} served a bot-check page instead of results")
    if use_cache:
        _cache_put(url, html)
    return html


def _fetch_with_browser(url: str, visible: bool = False) -> str:
    try:
        from playwright.sync_api import sync_playwright
    except ImportError as e:
        raise RuntimeError("Browser mode needs Playwright: pip install playwright && "
                           "python -m playwright install chromium") from e
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=not visible)
        page = browser.new_page(locale="en-US") if visible else browser.new_page(user_agent=USER_AGENT, locale="en-US")
        resp = page.goto(url, wait_until="domcontentloaded", timeout=HTTP_TIMEOUT * 2000)
        if resp is not None and resp.status in (403, 429) and not visible:
            browser.close()
            raise BlockedError(f"{url.split('/')[2]} returned HTTP {resp.status}")
        if visible:
            # Give the page (and you, if the site shows a check) up to 60 s to show results.
            try:
                page.wait_for_function(
                    "() => document.querySelector('#__NEXT_DATA__, li[role=article], article')",
                    timeout=60000)
            except Exception:
                pass
        page.wait_for_timeout(2500)
        html = page.content()
        browser.close()
        return html
