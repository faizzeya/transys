"""Live search of zillow.com (USA).

City pages look like  https://www.zillow.com/austin-tx/          (for sale)
                      https://www.zillow.com/austin-tx/rentals/  (for rent)
Neighbourhoods:       https://www.zillow.com/hyde-park-austin-tx/
Page N appends "N_p/". Results are embedded as JSON (__NEXT_DATA__); we read listResults from it,
including Zestimate / rent Zestimate, which the ranking uses as a market reference.

Zillow uses aggressive bot protection. Plain requests sometimes work, sometimes get HTTP 403.
'browser' fetch mode (Playwright) succeeds more often. The app never tries to solve CAPTCHAs –
if a check page appears it reports it and moves on.
"""
from __future__ import annotations

import json
import re
from urllib.parse import quote

from bs4 import BeautifulSoup

from models import Listing, SearchQuery
from sources.base import BlockedError, fetch_html
from sources.zameen import SourceResult
from units import parse_price, slug

BASE = "https://www.zillow.com"
_HOME_TYPES = {
    "SINGLE_FAMILY": "house", "CONDO": "condo", "TOWNHOUSE": "townhouse", "APARTMENT": "apartment",
    "MULTI_FAMILY": "multi-family", "LOT": "plot", "MANUFACTURED": "manufactured",
}


def build_url(q: SearchQuery, region_slug: str, page: int = 1) -> str:
    url = f"{BASE}/{region_slug}/" + ("rentals/" if q.purpose == "rent" else "")
    if page > 1:
        url += f"{page}_p/"
    filt = {}
    price_key = "mp" if q.purpose == "rent" else "price"
    if q.min_price or q.max_price:
        filt[price_key] = {k: int(v) for k, v in (("min", q.min_price), ("max", q.max_price)) if v}
    if q.beds:
        filt["beds"] = {"min": q.beds}
    if q.baths:
        filt["baths"] = {"min": q.baths}
    if q.purpose == "rent":
        filt.update({"fr": {"value": True}, "fsba": {"value": False}, "fsbo": {"value": False},
                     "nc": {"value": False}, "cmsn": {"value": False}, "auc": {"value": False},
                     "fore": {"value": False}})
    if filt or page > 1:
        state = {"pagination": {"currentPage": page} if page > 1 else {}, "isListVisible": True,
                 "filterState": filt}
        url += "?searchQueryState=" + quote(json.dumps(state, separators=(",", ":")))
    return url


def parse_listings(html: str, purpose: str = "buy") -> list[Listing]:
    soup = BeautifulSoup(html, "lxml")
    results = []
    for script in soup.find_all("script"):
        text = script.string or script.get_text() or ""
        if "zpid" not in text:
            continue
        text = text.strip()
        if text.startswith("<!--"):
            text = text[4:-3]
        try:
            data = json.loads(text)
        except Exception:
            m = re.search(r"(\{.*\})", text, flags=re.S)
            if not m:
                continue
            try:
                data = json.loads(m.group(1))
            except Exception:
                continue
        results.extend(_find_results(data))
    out, seen = [], set()
    for r in results:
        zpid = str(r.get("zpid") or r.get("id") or "")
        if not zpid or zpid in seen:
            continue
        seen.add(zpid)
        out.append(_to_listing(r, purpose))
    return [l for l in out if l.price]


def _find_results(obj, depth=0) -> list[dict]:
    """Collect every dict that looks like a Zillow search result (has zpid and a price)."""
    found = []
    if depth > 12:
        return found
    if isinstance(obj, dict):
        if "zpid" in obj and ("price" in obj or "unformattedPrice" in obj or "units" in obj):
            found.append(obj)
        else:
            for v in obj.values():
                found.extend(_find_results(v, depth + 1))
    elif isinstance(obj, list):
        for v in obj:
            found.extend(_find_results(v, depth + 1))
    return found


def _to_listing(r: dict, purpose: str) -> Listing:
    info = (r.get("hdpData") or {}).get("homeInfo") or {}
    price = r.get("unformattedPrice") or info.get("price") or parse_price(r.get("price"))
    if not price and r.get("units"):   # apartment buildings list unit prices
        unit_prices = [parse_price(u.get("price")) for u in r["units"] if u.get("price")]
        price = min(p for p in unit_prices if p) if any(unit_prices) else None
    url = r.get("detailUrl") or ""
    if url and not url.startswith("http"):
        url = BASE + url
    address = r.get("address") or ", ".join(
        x for x in (info.get("streetAddress"), info.get("city"), info.get("state")) if x)
    beds = r.get("beds") or info.get("bedrooms")
    baths = r.get("baths") or info.get("bathrooms")
    size = r.get("area") or info.get("livingArea")
    home_type = _HOME_TYPES.get(info.get("homeType") or "", (info.get("homeType") or "").lower() or None)
    estimate = info.get("rentZestimate") if purpose == "rent" else info.get("zestimate")
    desc_bits = [r.get("statusText"), r.get("flexFieldText"), r.get("brokerName"),
                 ", ".join(r.get("listingSubType", {}).keys()) if isinstance(r.get("listingSubType"), dict) else None]
    return Listing(
        source="zillow", listing_id=str(r.get("zpid")),
        title=address or "Zillow listing", url=url, price=float(price) if price else None, currency="USD",
        city=r.get("addressCity") or info.get("city"),
        location=", ".join(x for x in (r.get("addressStreet") or info.get("streetAddress"),
                                        r.get("addressCity") or info.get("city"),
                                        r.get("addressState") or info.get("state"),
                                        r.get("addressZipcode") or info.get("zipcode")) if x),
        beds=int(beds) if beds else None, baths=int(float(baths)) if baths else None,
        size_sqft=float(size) if size else None, size_text=f"{int(size):,} sqft" if size else None,
        property_type=home_type, description=" · ".join(str(b) for b in desc_bits if b),
        image=r.get("imgSrc"), market_estimate=float(estimate) if estimate else None, purpose=purpose,
    )


def search(q: SearchQuery, max_pages: int = 2, mode: str = "requests") -> SourceResult:
    res = SourceResult()
    if not q.city:
        res.notes.append("Zillow: no US city in the request, skipped.")
        return res
    if not q.state:
        res.notes.append(f"Zillow: add the state for '{q.city}' (e.g. '{q.city}, TX') so the right city is searched.")
        return res
    city_slug = f"{slug(q.city)}-{q.state.lower()}"
    regions = [f"{slug(q.area)}-{city_slug}", city_slug] if q.area else [city_slug]

    try:
        for region in regions:
            seen = set()
            for page in range(1, max_pages + 1):
                url = build_url(q, region, page)
                try:
                    html = fetch_html(url, mode=mode, extra_headers={"Referer": BASE + "/"})
                except BlockedError:
                    raise
                except Exception as e:
                    if page == 1 and region != regions[-1]:
                        res.notes.append(f"Zillow: no page for neighbourhood '{q.area}' ({e.__class__.__name__}); "
                                         f"searching all of {q.city}.")
                    break
                res.urls.append(url)
                batch = [l for l in parse_listings(html, q.purpose) if l.listing_id not in seen]
                seen.update(l.listing_id for l in batch)
                res.listings.extend(batch)
                if not batch:
                    break
            if res.listings:
                break
        if not res.listings and not any("blocked" in n for n in res.notes):
            res.notes.append("Zillow: no results parsed. The page may have been a bot check or the layout "
                             "changed; try 'browser' fetch mode.")
    except BlockedError as e:
        res.notes.append(f"Zillow blocked the request ({e}). This is common – try 'browser' fetch mode, "
                         "wait a few minutes, or use demo data to test the ranking.")
    return res
