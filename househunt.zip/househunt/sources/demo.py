"""Synthetic listings so the app (and the ML ranking) can be tried offline or when a site blocks.
Every listing is clearly marked source='demo' and links nowhere real."""
from __future__ import annotations

import random

from models import Listing, SearchQuery
from sources.zameen import SourceResult

PK_AREAS = {
    "Karachi": {"DHA Defence Phase 6": 95000, "DHA Defence Phase 8": 80000, "Clifton Block 5": 85000,
                "Bahria Town Karachi": 22000, "Gulshan-e-Iqbal Block 13": 40000, "PECHS": 55000,
                "North Nazimabad Block H": 38000, "Gulistan-e-Jauhar Block 3-A": 30000, "Scheme 33": 20000},
    "Lahore": {"DHA Phase 5": 60000, "DHA Phase 6": 55000, "Bahria Town Lahore": 25000,
               "Gulberg III": 75000, "Model Town": 50000, "Johar Town": 35000, "Wapda Town": 28000},
    "Islamabad": {"F-7": 120000, "E-11": 50000, "DHA Phase 2": 40000, "Bahria Town Phase 7": 30000,
                  "G-13": 38000, "B-17": 18000},
    "Rawalpindi": {"Bahria Town Phase 8": 26000, "Saddar": 30000, "Chaklala Scheme 3": 28000},
}
US_AREAS = {
    ("Austin", "TX"): {"Hyde Park": 420, "Mueller": 390, "Zilker": 560, "East Austin": 380, "Circle C": 300},
    ("Houston", "TX"): {"Montrose": 300, "The Heights": 330, "Katy": 170, "Sugar Land": 190, "Midtown": 280},
    ("Seattle", "WA"): {"Ballard": 620, "Capitol Hill": 680, "Queen Anne": 720, "Rainier Valley": 480},
    ("Chicago", "IL"): {"Lincoln Park": 420, "Wicker Park": 380, "Hyde Park": 230, "Lakeview": 360},
    ("Tulsa", "OK"): {"Brookside": 190, "Midtown": 170, "South Tulsa": 150, "Owasso": 140},
    ("San Jose", "CA"): {"Willow Glen": 950, "Almaden Valley": 880, "Evergreen": 820, "Downtown": 760},
}
PK_SIZES = [("5 Marla", 1125), ("7 Marla", 1575), ("10 Marla", 2250), ("1 Kanal", 4500),
            ("120 Sq. Yd.", 1080), ("240 Sq. Yd.", 2160), ("500 Sq. Yd.", 4500), ("2 Kanal", 9000)]
FEATURES_PK = ["corner", "park facing", "servant quarter", "basement", "near school", "brand new",
               "solar installed", "gated community", "double unit", "lawn", "furnished"]
FEATURES_US = ["pool", "updated kitchen", "garage", "near school", "new construction", "hardwood floors",
               "big backyard", "renovated", "walkable", "view", "basement"]


def search(q: SearchQuery, n: int = 80, seed: int = 7) -> SourceResult:
    rng = random.Random(f"{seed}-{q.country}-{q.city}-{q.purpose}")
    res = SourceResult(notes=["Demo data: synthetic listings for testing, not real properties."])
    if q.country == "US":
        key = next((k for k in US_AREAS if q.city and k[0].lower() == q.city.lower()), ("Austin", "TX"))
        res.listings = [_us(rng, key, q.purpose, i) for i in range(n)]
    else:
        city = q.city.title() if q.city and q.city.title() in PK_AREAS else "Karachi"
        res.listings = [_pk(rng, city, q.purpose, i) for i in range(n)]
    return res


def _pk(rng, city, purpose, i) -> Listing:
    area, rate = rng.choice(list(PK_AREAS[city].items()))
    size_text, sqft = rng.choice(PK_SIZES)
    ptype = rng.choices(["house", "flat", "plot"], [0.65, 0.25, 0.10])[0]
    if ptype == "flat":
        sqft = rng.choice([850, 1100, 1400, 1800, 2400])
        size_text = f"{sqft:,} Sq. Ft."
    beds = 0 if ptype == "plot" else max(1, min(7, round(sqft / 600) + rng.choice([-1, 0, 0, 1])))
    price = sqft * rate * rng.uniform(0.75, 1.3) * (0.6 if ptype == "plot" else 1)
    if purpose == "rent":
        price = price * rng.uniform(0.0028, 0.0042)
    feats = rng.sample(FEATURES_PK, 2)
    title = f"{size_text} {ptype.title()} for {'Rent' if purpose == 'rent' else 'Sale'} in {area}"
    return Listing(source="demo", listing_id=f"pk{i}", title=title, url="#", price=round(price, -3),
                   currency="PKR", city=city, location=f"{area}, {city}", beds=beds or None,
                   baths=(max(1, beds - rng.choice([0, 1])) if beds else None), size_sqft=sqft,
                   size_text=size_text, property_type=ptype,
                   description=f"{title}. {feats[0].capitalize()}, {feats[1]}.", purpose=purpose)


def _us(rng, key, purpose, i) -> Listing:
    city, state = key
    area, rate = rng.choice(list(US_AREAS[key].items()))
    ptype = rng.choices(["house", "condo", "townhouse"], [0.6, 0.25, 0.15])[0]
    sqft = rng.choice([750, 950, 1200, 1500, 1800, 2200, 2600, 3200])
    beds = max(1, min(6, round(sqft / 550) + rng.choice([-1, 0, 0, 1])))
    fair = sqft * rate
    price = fair * rng.uniform(0.8, 1.25)
    if purpose == "rent":
        fair, price = fair * 0.0055, price * 0.0055
    feats = rng.sample(FEATURES_US, 2)
    street = f"{rng.randint(100, 9999)} {rng.choice(['Oak', 'Maple', 'Cedar', 'Elm', 'Pine', 'Lake'])} " \
             f"{rng.choice(['St', 'Ave', 'Dr', 'Ln'])}"
    return Listing(source="demo", listing_id=f"us{i}", title=f"{street}, {area}, {city}, {state}", url="#",
                   price=round(price, -2 if purpose == "rent" else -3), currency="USD", city=city,
                   location=f"{street}, {area}, {city}, {state}", beds=beds,
                   baths=max(1, beds - rng.choice([0, 1])), size_sqft=sqft, size_text=f"{sqft:,} sqft",
                   property_type=ptype, description=f"{ptype.title()} in {area} with {feats[0]} and {feats[1]}.",
                   market_estimate=round(fair * rng.uniform(0.95, 1.05), -2), purpose=purpose)
