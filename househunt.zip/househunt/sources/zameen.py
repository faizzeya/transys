"""Live search of zameen.com (Pakistan).

URL scheme (verified Oct 2026):
    /Homes/Karachi-2-1.html                      all homes for sale in a city, page 1
    /Homes/Karachi_DHA_Defence-213-1.html        a location inside the city (ID 213)
    /Houses_Property/..., /Flats_Apartments/...  by property type
    /Rentals/..., /Rentals_Houses_Property/...   rentals
Page N replaces the trailing "-1.html" with "-N.html".

Locations (DHA Defence, Bahria Town, Gulshan-e-Iqbal ...) are resolved by reading the location
links Zameen prints on its own pages; every location seen is remembered in .cache/zameen_locations.json
so repeated searches resolve instantly.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from urllib.parse import urlencode

from bs4 import BeautifulSoup
from rapidfuzz import fuzz, process

from config import CACHE_DIR
from models import Listing, SearchQuery
from sources.base import BlockedError, fetch_html
from units import ZAMEEN_CITY_IDS, parse_area_sqft, parse_int, parse_price

BASE = "https://www.zameen.com"

_TYPE_PATH = {
    ("buy", None): "Homes", ("buy", "house"): "Houses_Property", ("buy", "villa"): "Houses_Property",
    ("buy", "flat"): "Flats_Apartments", ("buy", "apartment"): "Flats_Apartments",
    ("buy", "penthouse"): "Flats_Apartments", ("buy", "plot"): "Plots",
    ("rent", None): "Rentals", ("rent", "house"): "Rentals_Houses_Property",
    ("rent", "villa"): "Rentals_Houses_Property", ("rent", "flat"): "Rentals_Flats_Apartments",
    ("rent", "apartment"): "Rentals_Flats_Apartments", ("rent", "penthouse"): "Rentals_Flats_Apartments",
}
_LOC_LINK_RE = re.compile(r"/[A-Za-z_]+/([A-Z][A-Za-z0-9_.]*?)-(\d+)-\d+\.html")
_LOC_FILE = CACHE_DIR / "zameen_locations.json"


@dataclass
class SourceResult:
    listings: list[Listing] = field(default_factory=list)
    urls: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)


# ---- location index -------------------------------------------------------------------------

def _load_locations() -> dict:
    try:
        return json.loads(_LOC_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_locations(index: dict) -> None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    _LOC_FILE.write_text(json.dumps(index, indent=1), encoding="utf-8")


_ANCHOR_RE = re.compile(r'href="/[A-Za-z_]+/([^"/?]+?)-(\d+)-1\.html"[^>]*>([^<]{2,80})<')
_JSON_LOC_RE = re.compile(r'"name":"([^"]{2,80})","externalID":"(\d+)"[^{}]*?"slug":"(?:\\u002F|/)([^"]+?)-\2"')


def _harvest_locations(html: str, city: str, index: dict) -> None:
    """Record every location link on a page with its display name and ID,
    e.g. Karachi_D.H.A_DHA_Phase_6 -> {"id": 1483, "name": "DHA Phase 6"}."""
    prefix = city.replace(" ", "_") + "_"
    bucket = index.setdefault(city.lower(), {})
    for k, v in list(bucket.items()):          # migrate old {slug: id} entries
        if isinstance(v, int):
            bucket[k] = {"id": v, "name": k[len(prefix):].replace("_", " ")}
    for slug_, loc_id in _LOC_LINK_RE.findall(html):
        if slug_.startswith(prefix) and slug_ not in bucket:
            bucket[slug_] = {"id": int(loc_id), "name": slug_[len(prefix):].replace("_", " ")}
    for slug_, loc_id, name in _ANCHOR_RE.findall(html):
        if slug_.startswith(prefix) and "<" not in name:
            bucket[slug_] = {"id": int(loc_id), "name": name.strip()}
    for name, loc_id, slug_ in _JSON_LOC_RE.findall(html):
        if slug_.startswith(prefix):
            bucket[slug_] = {"id": int(loc_id), "name": name}


def _names(city: str, index: dict) -> dict:
    out = {}
    for slug_, v in index.get(city.lower(), {}).items():
        if isinstance(v, int):
            v = {"id": v, "name": slug_.split("_", 1)[-1].replace("_", " ")}
        out[slug_] = v
    return out


def _resolve_area(city: str, area: str, index: dict) -> tuple[str, int] | None:
    locs = _names(city, index)
    if not locs:
        return None
    names = {s: v["name"] for s, v in locs.items()}
    hits = process.extract(area, names, scorer=fuzz.token_set_ratio, limit=10)
    want_nums = set(re.findall(r"\d+", area))
    good = [h for h in hits if h[1] >= 85 and (not want_nums or want_nums & set(re.findall(r"\d+", h[0])))]
    if not good:
        return None
    best = max(good, key=lambda h: (h[1], fuzz.ratio(area.lower(), h[0].lower()), -len(h[0])))
    return best[2], locs[best[2]]["id"]


def _parent_candidate(city: str, area: str, index: dict) -> tuple[str, int] | None:
    """For 'DHA Phase 6' find the broader known location 'DHA Defence' to drill into."""
    locs = _names(city, index)
    words = {w for w in re.findall(r"[a-z]{3,}", area.lower()) if w not in ("phase", "block", "sector", "town")}
    best, best_score = None, 0
    for s, v in locs.items():
        lw = set(re.findall(r"[a-z]{3,}", v["name"].lower()))
        score = len(words & lw) * 100 + fuzz.partial_ratio(area.lower(), v["name"].lower()) / 10 - len(v["name"]) / 100
        if words & lw and score > best_score:
            best, best_score = (s, v["id"]), score
    return best


# ---- URL building -------------------------------------------------------------------------

def _type_key(q: SearchQuery):
    pt = (q.property_type or "").lower() or None
    if pt in ("townhouse", "bungalow", "home"):
        pt = "house"
    if pt == "condo":
        pt = "apartment"
    return (q.purpose, pt) if (q.purpose, pt) in _TYPE_PATH else (q.purpose, None)


def build_url(q: SearchQuery, loc_slug: str, loc_id: int, page: int = 1) -> str:
    path = _TYPE_PATH[_type_key(q)]
    params = {}
    if q.min_price:
        params["price_min"] = int(q.min_price)
    if q.max_price:
        params["price_max"] = int(q.max_price)
    if q.beds:
        params["beds_in"] = q.beds
    url = f"{BASE}/{path}/{loc_slug}-{loc_id}-{page}.html"
    return url + ("?" + urlencode(params) if params else "")


# ---- parsing ------------------------------------------------------------------------------

def _jsonld_items(soup) -> dict[str, dict]:
    """url -> {description, type, price, name, image} from the page's schema.org ItemList."""
    items = {}
    for s in soup.select('script[type="application/ld+json"]'):
        try:
            data = json.loads(s.string or "")
        except Exception:
            continue
        for d in data if isinstance(data, list) else [data]:
            for el in (d.get("itemListElement") or []) if isinstance(d, dict) else []:
                it = el.get("item") if isinstance(el, dict) else None
                if not isinstance(it, dict) or not it.get("url"):
                    continue
                ptype = next((p.get("value") for p in it.get("additionalProperty", [])
                              if isinstance(p, dict) and p.get("name") == "Property Type"), None)
                offer = it.get("offers") or {}
                items[it["url"]] = {"description": it.get("description") or "", "type": ptype,
                                    "price": offer.get("price") if isinstance(offer, dict) else None,
                                    "name": it.get("name"), "image": it.get("image")}
    return items


def parse_listings(html: str, purpose: str = "buy", city: str | None = None) -> list[Listing]:
    soup = BeautifulSoup(html, "lxml")
    ld = _jsonld_items(soup)
    out: list[Listing] = []
    cards = soup.select('li[role="article"]') or soup.select('[aria-label="Listing"]')
    for card in cards:
        link = card.select_one('a[href*="/Property/"]')
        if not link:
            continue
        href = link["href"]
        url = href if href.startswith("http") else BASE + href
        def txt(label):
            el = card.select_one(f'[aria-label="{label}"]')
            return el.get_text(" ", strip=True) if el else None
        price_text = txt("Price")
        title = txt("Title") or link.get("title") or link.get_text(" ", strip=True)
        size_text = txt("Area")
        img = card.select_one("img")
        lid = re.search(r"-(\d+)-\d+-\d+\.html", href) or re.search(r"(\d{5,})", href)
        extra = ld.get(url, {})
        img_src = (img.get("src") or img.get("data-src")) if img else None
        if img_src and img_src.startswith("data:"):
            img_src = None
        out.append(Listing(
            source="zameen",
            listing_id=lid.group(1) if lid else href,
            title=(title or "Zameen listing")[:200],
            url=url,
            price=parse_price(price_text) or parse_price(extra.get("price")),
            currency="PKR",
            city=city,
            location=txt("Location"),
            beds=parse_int(txt("Beds")),
            baths=parse_int(txt("Baths")),
            size_sqft=parse_area_sqft(size_text),
            size_text=size_text,
            property_type=(extra.get("type") or _guess_type(title) or "").lower() or None,
            description=(extra.get("description") or "")[:1000],
            image=img_src or extra.get("image"),
            purpose=purpose,
        ))
    if not out:
        out = _from_jsonld(ld, purpose, city) or _parse_state_json(html, purpose, city)
    return out


def _from_jsonld(ld: dict, purpose: str, city: str | None) -> list[Listing]:
    out = []
    for url, it in ld.items():
        lid = re.search(r"-(\d+)-\d+-\d+\.html", url)
        out.append(Listing(source="zameen", listing_id=lid.group(1) if lid else url,
                           title=(it.get("name") or "Zameen listing")[:200], url=url,
                           price=parse_price(it.get("price")), currency="PKR", city=city,
                           property_type=(it.get("type") or "").lower() or None,
                           description=it.get("description", "")[:1000], image=it.get("image"),
                           size_sqft=parse_area_sqft(it.get("description")), purpose=purpose))
    return out


def _guess_type(title: str | None) -> str | None:
    t = (title or "").lower()
    for k in ("house", "flat", "apartment", "plot", "penthouse", "villa", "portion", "farm house"):
        if k in t:
            return k
    return None


def _parse_state_json(html: str, purpose: str, city: str | None) -> list[Listing]:
    """Fallback: Zameen (like other Dubizzle-group sites) embeds search hits in window.state."""
    m = re.search(r"window\.state\s*=\s*(\{.*?\});\s*</script>", html, flags=re.S)
    if not m:
        return []
    try:
        state = json.loads(m.group(1))
    except Exception:
        return []
    hits = _find_hits(state)
    out = []
    for h in hits:
        locs = h.get("location") or []
        loc_names = [l.get("name") for l in locs if isinstance(l, dict) and l.get("name")]
        area_val = h.get("area")
        size = float(area_val) * 10.7639 if isinstance(area_val, (int, float)) else None  # stored in m²
        ext = str(h.get("externalID") or h.get("id"))
        url = h.get("url") or f"{BASE}/Property/{h.get('slug', 'details')}-{ext}.html"
        out.append(Listing(
            source="zameen", listing_id=ext, title=str(h.get("title", "Zameen listing"))[:200],
            url=url if url.startswith("http") else BASE + url, price=parse_price(h.get("price")),
            currency="PKR", city=city or (loc_names[1] if len(loc_names) > 1 else None),
            location=", ".join(reversed(loc_names[2:])) or None, beds=parse_int(h.get("rooms")),
            baths=parse_int(h.get("baths")), size_sqft=size,
            size_text=f"{size:,.0f} sq ft" if size else None,
            property_type=_guess_type(h.get("title")), description=str(h.get("description", ""))[:1000],
            purpose=purpose,
        ))
    return out


def _find_hits(obj, depth=0):
    if depth > 8:
        return []
    if isinstance(obj, list) and obj and isinstance(obj[0], dict) and "externalID" in obj[0] and "price" in obj[0]:
        return obj
    items = obj.values() if isinstance(obj, dict) else obj if isinstance(obj, list) else []
    for v in items:
        r = _find_hits(v, depth + 1)
        if r:
            return r
    return []


# ---- public API ---------------------------------------------------------------------------

def search(q: SearchQuery, max_pages: int = 2, mode: str = "requests") -> SourceResult:
    res = SourceResult()
    city = (q.city or "").strip()
    if not city:
        res.notes.append("Zameen: no Pakistani city in the request, skipped.")
        return res
    city_id = ZAMEEN_CITY_IDS.get(city.lower())
    if city_id is None:
        res.notes.append(f"Zameen: city ID for '{city}' is not known yet. Add it to ZAMEEN_CITY_IDS "
                         "in units.py (open the city on zameen.com and copy the number from the URL).")
        return res
    city_slug = city.title().replace(" ", "_")

    index = _load_locations()
    loc_slug, loc_id = city_slug, city_id
    try:
        if q.area:
            hit = _resolve_area(city, q.area, index)
            if hit is None:
                # read the city page once to learn its locations, then retry
                html = fetch_html(f"{BASE}/Homes/{city_slug}-{city_id}-1.html", mode=mode)
                _harvest_locations(html, city_slug, index)
                _save_locations(index)
                hit = _resolve_area(city, q.area, index)
            if hit is None:
                parent = _parent_candidate(city, q.area, index)   # drill one level deeper
                if parent:
                    html = fetch_html(f"{BASE}/Homes/{parent[0]}-{parent[1]}-1.html", mode=mode)
                    _harvest_locations(html, city_slug, index)
                    _save_locations(index)
                    hit = _resolve_area(city, q.area, index) or parent
            if hit:
                loc_slug, loc_id = hit
                res.notes.append(f"Zameen: '{q.area}' matched location '{_names(city, index).get(loc_slug, {}).get('name', loc_slug)}' (ID {loc_id}).")
            else:
                res.notes.append(f"Zameen: couldn't find '{q.area}' as a Zameen location; searched all of "
                                 f"{city} and ranked by area text instead.")

        seen = set()
        for page in range(1, max_pages + 1):
            url = build_url(q, loc_slug, loc_id, page)
            html = fetch_html(url, mode=mode)
            res.urls.append(url)
            _harvest_locations(html, city_slug, index)
            batch = [l for l in parse_listings(html, q.purpose, city.title()) if l.listing_id not in seen]
            seen.update(l.listing_id for l in batch)
            res.listings.extend(batch)
            if not batch:
                break
        _save_locations(index)
        if not res.listings:
            res.notes.append("Zameen: page loaded but no listing cards were found – the site layout may "
                             "have changed, or try 'browser' fetch mode.")
    except BlockedError as e:
        res.notes.append(f"Zameen blocked the request ({e}). Wait a while, or try 'browser' fetch mode.")
    except Exception as e:  # network errors etc.
        res.notes.append(f"Zameen error: {e.__class__.__name__}: {e}")
    return res
