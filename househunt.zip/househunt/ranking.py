"""The machine-learning layer.

Each listing gets five scores in [0, 1]:
  semantic  – how close the listing text is to the request (Ollama embeddings, or TF-IDF fallback)
  location  – fuzzy match of the requested town/area against the listing's location
  price     – inside the requested budget = 1, decays smoothly outside it
  specs     – beds, baths, size, property type, wished-for features
  value     – price vs. a fair-price estimate learned from the *other* listings in the same search
              (RandomForest on size, beds, baths, type and location, out-of-fold so a listing never
              prices itself), blended with Zillow's Zestimate when available.
The final match score is a weighted average the user can tune in the sidebar.
"""
from __future__ import annotations

import math
import re
from typing import Optional

import numpy as np
import pandas as pd
from rapidfuzz import fuzz
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.model_selection import KFold, cross_val_predict

from models import Listing, SearchQuery

DEFAULT_WEIGHTS = {"semantic": 0.25, "location": 0.25, "price": 0.20, "specs": 0.20, "value": 0.10}


# ---- semantic -----------------------------------------------------------------------------

def _query_text(q: SearchQuery) -> str:
    bits = [q.raw, q.area or "", q.city or "", q.property_type or "", " ".join(q.keywords)]
    return " ".join(b for b in bits if b)


def semantic_scores(listings: list[Listing], q: SearchQuery, client=None, embed_model: Optional[str] = None
                    ) -> tuple[np.ndarray, str]:
    docs = [l.text_blob() for l in listings]
    qtext = _query_text(q)
    if client is not None and embed_model:
        vecs = client.embed(embed_model, [qtext] + docs)
        if vecs and len(vecs) == len(docs) + 1:
            m = np.asarray(vecs, dtype=float)
            sims = cosine_similarity(m[:1], m[1:])[0]
            return _rescale(sims), f"Ollama embeddings ({embed_model})"
    vec = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True, stop_words="english")
    try:
        m = vec.fit_transform(docs + [qtext])
        sims = cosine_similarity(m[-1], m[:-1])[0]
    except ValueError:
        sims = np.zeros(len(docs))
    return _rescale(sims), "TF-IDF"


def _rescale(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    lo, hi = np.nanmin(x), np.nanmax(x)
    return np.full_like(x, 0.5) if hi - lo < 1e-9 else (x - lo) / (hi - lo)


# ---- structured scores ------------------------------------------------------------------

def location_score(l: Listing, q: SearchQuery) -> float:
    hay = f"{l.location or ''} {l.title}".lower()
    city_ok = 1.0 if not q.city or (q.city.lower() in hay or (l.city or "").lower() == q.city.lower()) else 0.4
    if not q.area:
        return city_ok
    area = q.area.lower()
    s = max(fuzz.token_set_ratio(area, hay), fuzz.partial_ratio(area, hay)) / 100
    # phase/sector/block numbers must agree ("DHA Phase 6" != "DHA Phase 8")
    want = re.findall(r"(?:phase|sector|block)\s*([\w-]+)", area)
    have = re.findall(r"(?:phase|sector|block)\s*([\w-]+)", hay)
    if want and have and not set(want) & set(have):
        s *= 0.6
    return round(s * city_ok, 4)


def price_score(price: Optional[float], q: SearchQuery) -> float:
    if price is None:
        return 0.3
    lo, hi = q.min_price, q.max_price
    if not lo and not hi:
        return 1.0
    if lo and price < lo:
        return math.exp(-((lo - price) / lo) / 0.25)
    if hi and price > hi:
        return math.exp(-((price - hi) / hi) / 0.15)   # over budget hurts more than under
    return 1.0


def specs_score(l: Listing, q: SearchQuery) -> float:
    parts, weights = [], []

    def add(s, w):
        parts.append(s)
        weights.append(w)

    if q.beds:
        add(0.4 if l.beds is None else {0: 1.0, 1: 0.6}.get(abs(l.beds - q.beds), 0.15), 2)
    if q.baths:
        add(0.5 if l.baths is None else {0: 1.0, 1: 0.7}.get(abs(l.baths - q.baths), 0.3), 1)
    if q.min_size_sqft or q.max_size_sqft:
        if l.size_sqft is None:
            add(0.4, 1.5)
        else:
            lo = q.min_size_sqft or 0
            hi = q.max_size_sqft or float("inf")
            if lo <= l.size_sqft <= hi:
                add(1.0, 1.5)
            else:
                edge = lo if l.size_sqft < lo else hi
                add(math.exp(-abs(l.size_sqft - edge) / max(edge, 1) / 0.2), 1.5)
    if q.property_type:
        pt = (l.property_type or "").lower()
        want = q.property_type.lower()
        same = {"flat": "apartment", "apartment": "flat", "condo": "apartment"}
        add(1.0 if (want in pt or pt in want or same.get(want) == pt) and pt else (0.5 if not pt else 0.2), 1.5)
    if q.keywords:
        text = l.text_blob().lower()
        hit = sum(1 for k in q.keywords if k.lower() in text)
        add(0.3 + 0.7 * hit / len(q.keywords), 1)
    return float(np.average(parts, weights=weights)) if parts else 1.0


_TYPE_FAMILY = {
    "house": "house", "villa": "house", "bungalow": "house", "townhouse": "house", "home": "house",
    "farm house": "house", "multi-family": "house", "portion": "house",
    "flat": "apartment", "apartment": "apartment", "condo": "apartment", "penthouse": "apartment",
    "plot": "land", "lot": "land", "land": "land",
}


def type_matches(have: Optional[str], want: Optional[str]) -> Optional[bool]:
    """True / False when both types are known, None when either is unknown."""
    if not have or not want:
        return None
    fh = _TYPE_FAMILY.get(have.lower().strip())
    fw = _TYPE_FAMILY.get(want.lower().strip())
    if fh is None or fw is None:
        return None
    return fh == fw


# ---- fair-price model ---------------------------------------------------------------------

def _loc_group(l: Listing) -> str:
    if l.currency == "USD":
        m = re.search(r"\b(\d{5})\b", l.location or "")
        if m:
            return m.group(1)
        parts = [p.strip() for p in (l.location or "").split(",") if p.strip()]
        if len(parts) >= 3:          # "street, neighbourhood, city, ST" -> neighbourhood
            return parts[-3].lower()
    loc = (l.location or l.title or "").split(",")[0].lower()
    loc = re.sub(r"\b(block|sector|street|st)\b.*$", "", loc).strip()
    return loc or "unknown"


def fair_prices(df: pd.DataFrame) -> tuple[pd.Series, str]:
    """Estimate a fair price for each listing from its peers. Returns (fair_price, method)."""
    ok = df["price"].notna() & (df["price"] > 0)
    fair = pd.Series(np.nan, index=df.index)
    d = df[ok].copy()
    if len(d) < 4:
        return fair, "not enough listings to compare"

    size_med = d["size_sqft"].median() if d["size_sqft"].notna().any() else 1000.0
    d["size_f"] = d["size_sqft"].fillna(size_med).clip(lower=100)
    d["log_price"] = np.log(d["price"])
    d["log_size"] = np.log(d["size_f"])
    d["beds_f"] = d["beds"].fillna(d["beds"].median() if d["beds"].notna().any() else 0)
    d["baths_f"] = d["baths"].fillna(d["baths"].median() if d["baths"].notna().any() else 0)
    d["type_f"] = d["property_type"].fillna("unknown").astype("category").cat.codes
    d["log_ppsf"] = d["log_price"] - d["log_size"]

    # smoothed leave-one-out target encoding of location → no listing sees its own price
    g = d.groupby("loc_group")["log_ppsf"]
    s, c, glob, k = g.transform("sum"), g.transform("count"), d["log_ppsf"].mean(), 3
    d["loc_te"] = ((s - d["log_ppsf"]) + glob * k) / ((c - 1) + k)

    if len(d) >= 20:
        X = d[["log_size", "beds_f", "baths_f", "type_f", "loc_te"]].values
        model = RandomForestRegressor(n_estimators=200, min_samples_leaf=3, random_state=0, n_jobs=-1)
        pred = cross_val_predict(model, X, d["log_price"].values,
                                 cv=KFold(n_splits=5, shuffle=True, random_state=0))
        fair[d.index] = np.exp(pred)
        method = f"RandomForest fair-price model, 5-fold out-of-fold, {len(d)} listings"
    else:
        fair[d.index] = np.exp(d["loc_te"] + d["log_size"])
        method = f"price-per-sq-ft of comparable listings ({len(d)} listings)"
    return fair, method


def _deal(ratio: float) -> str:
    if np.isnan(ratio):
        return "—"
    if ratio < 0.85:
        return "Great value"
    if ratio < 0.95:
        return "Below market"
    if ratio <= 1.07:
        return "Fair price"
    if ratio <= 1.2:
        return "Above market"
    return "Overpriced"


# ---- public API ----------------------------------------------------------------------------

def rank(listings: list[Listing], q: SearchQuery, client=None, embed_model: Optional[str] = None,
         weights: Optional[dict] = None) -> tuple[pd.DataFrame, dict]:
    if not listings:
        return pd.DataFrame(), {}
    w = {**DEFAULT_WEIGHTS, **(weights or {})}
    df = pd.DataFrame([l.to_dict() for l in listings])
    df["loc_group"] = [_loc_group(l) for l in listings]

    df["semantic"], sem_method = semantic_scores(listings, q, client, embed_model)
    df["location_s"] = [location_score(l, q) for l in listings]
    df["price_s"] = [price_score(l.price, q) for l in listings]
    df["specs_s"] = [specs_score(l, q) for l in listings]

    model_fair, fair_method = fair_prices(df)
    est = df["market_estimate"].astype(float)
    df["fair_price"] = np.where(est.notna() & model_fair.notna(), 0.5 * est + 0.5 * model_fair,
                                np.where(est.notna(), est, model_fair))
    df["value_ratio"] = df["price"] / df["fair_price"]
    df["value_s"] = ((1.3 - df["value_ratio"]) / 0.6).clip(0, 1).fillna(0.5)
    df["deal"] = df["value_ratio"].apply(_deal)

    peer = df.groupby("loc_group")["price"]
    df["peer_median_price"] = peer.transform("median")
    df["peers"] = peer.transform("count")
    df["price_per_sqft"] = df["price"] / df["size_sqft"]

    total = sum(w.values()) or 1
    df["match_score"] = (w["semantic"] * df["semantic"] + w["location"] * df["location_s"] +
                         w["price"] * df["price_s"] + w["specs"] * df["specs_s"] +
                         w["value"] * df["value_s"]) / total
    # a plot is not a house: wrong property category is a hard penalty, not just a lower sub-score
    df["type_ok"] = [type_matches(l.property_type, q.property_type) for l in listings]
    df.loc[df["type_ok"] == False, "match_score"] *= 0.6  # noqa: E712
    df = df.sort_values("match_score", ascending=False).reset_index(drop=True)
    return df, {"semantic_method": sem_method, "fair_price_method": fair_method}


def apply_strict_filters(df: pd.DataFrame, q: SearchQuery, tolerance: float = 0.10) -> pd.DataFrame:
    """Hard filters: drop listings clearly outside budget / bedrooms / city."""
    if df.empty:
        return df
    keep = pd.Series(True, index=df.index)
    if q.max_price:
        keep &= df["price"].isna() | (df["price"] <= q.max_price * (1 + tolerance))
    if q.min_price:
        keep &= df["price"].isna() | (df["price"] >= q.min_price * (1 - tolerance))
    if q.beds:
        keep &= df["beds"].isna() | ((df["beds"] - q.beds).abs() <= 1)
    if "type_ok" in df:
        keep &= df["type_ok"] != False  # noqa: E712
    return df[keep].reset_index(drop=True)
