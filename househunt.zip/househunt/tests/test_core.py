"""Offline tests: run with  python -m pytest -q  from the project folder."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from llm import extract_json, rule_based_parse, _from_llm_dict, _merge  # noqa: E402
from models import SearchQuery  # noqa: E402
from ranking import apply_strict_filters, rank  # noqa: E402
from sources import demo, zameen, zillow  # noqa: E402
from units import format_price, parse_area_sqft, parse_price  # noqa: E402


def test_prices():
    assert parse_price("PKR 2.5 Crore") == 25_000_000
    assert parse_price("75 Lakh") == 7_500_000
    assert parse_price("1 Crore 20 Lakh") == 12_000_000
    assert parse_price("$450,000") == 450_000
    assert parse_price("1.2M") == 1_200_000
    assert parse_price("500k") == 500_000
    assert parse_price("1.5 Arab") == 1_500_000_000
    assert format_price(25_000_000, "PKR") == "PKR 2.50 Crore"


def test_areas():
    assert parse_area_sqft("10 Marla") == 2250
    assert parse_area_sqft("1 Kanal") == 4500
    assert parse_area_sqft("240 Sq. Yd.") == 2160
    assert parse_area_sqft("1,850 sqft") == 1850


def test_rule_parser_pk():
    q = rule_based_parse("10 marla house in DHA Phase 6 Lahore under 6 crore, 4 beds, corner preferred")
    assert (q.country, q.city, q.purpose, q.property_type) == ("PK", "Lahore", "buy", "house")
    assert q.max_price == 60_000_000 and q.beds == 4
    assert q.area == "Dha Phase 6"
    assert "corner" in q.keywords
    assert 2000 < q.min_size_sqft < 2250 < q.max_size_sqft


def test_rule_parser_range_and_rent():
    q = rule_based_parse("Family home in Bahria Town Karachi between 1.5 and 3 crore with 5 bedrooms")
    assert q.min_price == 15_000_000 and q.max_price == 30_000_000 and q.beds == 5
    q = rule_based_parse("3 bedroom flat for rent in Clifton Karachi around 2 lakh per month")
    assert q.purpose == "rent" and q.property_type == "flat"
    assert 160_000 < q.min_price < 200_000 < q.max_price


def test_rule_parser_us():
    q = rule_based_parse("3 bed 2 bath house in Austin, TX under $550k with a garage")
    assert (q.country, q.city, q.state, q.beds, q.baths, q.max_price) == ("US", "Austin", "TX", 3, 2, 550_000)


def test_llm_json_handling():
    raw = "<think>user wants lahore...</think>\n```json\n{\"country\":\"PK\",\"city\":\"lahore\",\"area\":\"DHA Phase 6\"," \
          "\"purpose\":\"buy\",\"min_price\":null,\"max_price\":600000000,\"beds\":4,\"keywords\":[]}\n```"
    d = extract_json(raw)
    llm_q = _from_llm_dict(d, "house in DHA Phase 6 Lahore under 6 crore 4 beds")
    merged = _merge(llm_q, rule_based_parse(llm_q.raw))
    assert merged.city == "Lahore" and merged.max_price == 60_000_000   # rules fix the crore mistake


ZAMEEN_HTML = """<ul>
<li role="article"><article>
 <a href="/Property/lahore_dha_phase_6_10_marla_house-12345678-1234-1.html" title="10 Marla House For Sale">x</a>
 <img src="https://img/1.jpg"/>
 <span aria-label="Price">5.4 Crore</span><div aria-label="Location">DHA Phase 6, Lahore</div>
 <span aria-label="Beds">4</span><span aria-label="Baths">5</span><span aria-label="Area">10 Marla</span>
 <h2 aria-label="Title">Corner 10 Marla House For Sale</h2>
</article></li></ul>
<a href="/Homes/Lahore_DHA_Defence-9-1.html">DHA Defence<span>(9)</span></a> <a href="/Homes/Lahore_D.H.A_Phase_6-1449-1.html">DHA Phase 6</a> <a href="/Homes/Lahore_D.H.A_Phase_5-1448-1.html">DHA Phase 5</a>"""


def test_zameen_parse_and_locations():
    ls = zameen.parse_listings(ZAMEEN_HTML, "buy", "Lahore")
    assert len(ls) == 1
    l = ls[0]
    assert l.price == 54_000_000 and l.beds == 4 and l.size_sqft == 2250 and l.listing_id == "12345678"
    idx = {}
    zameen._harvest_locations(ZAMEEN_HTML, "Lahore", idx)
    assert zameen._resolve_area("Lahore", "DHA Phase 6", idx) == ("Lahore_D.H.A_Phase_6", 1449)
    q = SearchQuery(city="Lahore", country="PK", max_price=6e7, beds=4)
    assert zameen.build_url(q, "Lahore_DHA_Phase_6", 1449, 2) == \
        "https://www.zameen.com/Homes/Lahore_DHA_Phase_6-1449-2.html?price_max=60000000&beds_in=4"


def test_zillow_parse_and_url():
    data = {"props": {"pageProps": {"searchPageState": {"cat1": {"searchResults": {"listResults": [{
        "zpid": "29384756", "detailUrl": "/homedetails/123-Oak-St-Austin-TX-78751/29384756_zpid/",
        "price": "$499,000", "unformattedPrice": 499000, "address": "123 Oak St, Austin, TX 78751",
        "addressStreet": "123 Oak St", "addressCity": "Austin", "addressState": "TX", "addressZipcode": "78751",
        "beds": 3, "baths": 2, "area": 1620, "statusText": "House for sale",
        "hdpData": {"homeInfo": {"homeType": "SINGLE_FAMILY", "zestimate": 520000}}}]}}}}}}
    html = f'<script id="__NEXT_DATA__" type="application/json">{json.dumps(data)}</script>'
    ls = zillow.parse_listings(html)
    assert len(ls) == 1 and ls[0].price == 499000 and ls[0].market_estimate == 520000
    assert ls[0].property_type == "house" and ls[0].url.startswith("https://www.zillow.com/homedetails")
    q = SearchQuery(city="Austin", state="TX", country="US", purpose="rent", max_price=3000)
    assert zillow.build_url(q, "austin-tx").startswith("https://www.zillow.com/austin-tx/rentals/?searchQueryState=")


def test_ranking_demo():
    q = rule_based_parse("10 marla house in DHA Phase 6 Lahore under 15 crore, 4 beds, corner preferred")
    res = demo.search(q)
    df, info = rank(res.listings, q)
    assert len(df) == 80 and "RandomForest" in info["fair_price_method"]
    top = df.iloc[0]
    assert "dha phase 6" in top["location"].lower()
    assert df["match_score"].is_monotonic_decreasing
    f = apply_strict_filters(df, q)
    assert (f["price"] <= 15e7 * 1.1).all()


def test_ranking_us_uses_zestimate():
    q = rule_based_parse("3 bed house in Hyde Park Austin, TX under $600k")
    df, _ = rank(demo.search(q).listings, q)
    assert df["fair_price"].notna().all()
    assert "hyde park" in df.iloc[0]["location"].lower()


def test_wrong_type_is_penalised():
    q = rule_based_parse("10 marla house in DHA Phase 6 Lahore under 6 crore, 4 beds")
    df, _ = rank(demo.search(q).listings, q)
    assert all(t in ("house",) for t in df.head(5)["property_type"])
    assert "plot" not in set(apply_strict_filters(df, q)["property_type"])
