"""HouseHunt AI – natural-language house search across zameen.com (Pakistan) and zillow.com (USA).

Run:  streamlit run app.py
"""
from __future__ import annotations

import shutil
import time

import altair as alt
import pandas as pd
import streamlit as st

from config import CACHE_DIR, DEFAULT_EMBED_MODEL, DEFAULT_MAX_PAGES, DEFAULT_MODEL, OLLAMA_URL
from llm import OllamaClient, explain_results, parse_query
from models import Listing, SearchQuery
from ranking import DEFAULT_WEIGHTS, apply_strict_filters, rank
from sources import demo, zameen, zillow
from units import US_STATES, format_price

st.set_page_config(page_title="HouseHunt AI", page_icon="🏠", layout="wide")

EXAMPLES = [
    "10 marla house in DHA Phase 6 Lahore under 6 crore, 4 beds, corner preferred",
    "3 bedroom flat for rent in Clifton Karachi around 2 lakh per month",
    "Family home in Bahria Town Karachi between 1.5 and 3 crore with 5 bedrooms",
    "3 bed 2 bath house in Austin, TX under $550k with a garage",
    "2 bedroom condo for rent in Capitol Hill Seattle under $3,000",
    "Single family home in Tulsa, OK around $300,000 near a good school",
]
NO_EMBED = "TF-IDF (built-in, no model needed)"


# ---- sidebar ------------------------------------------------------------------------------
with st.sidebar:
    st.header("⚙️ Settings")
    ollama_url = st.text_input("Ollama URL", OLLAMA_URL)
    client = OllamaClient(ollama_url)
    up = client.available()
    models = client.list_models() if up else []
    chat_models = [m for m in models if not client.is_embedding_model(m)]
    embed_models = [m for m in models if client.is_embedding_model(m)]

    if not up:
        st.error("Ollama is not reachable. Start it with `ollama serve`. "
                 "Until then a rule-based parser is used.")
        llm_model = None
    elif not chat_models:
        st.warning(f"No chat models installed. Run `ollama pull {DEFAULT_MODEL}`.")
        llm_model = None
    else:
        idx = chat_models.index(DEFAULT_MODEL) if DEFAULT_MODEL in chat_models else 0
        llm_model = st.selectbox("LLM model (from your Ollama)", chat_models, index=idx,
                                 help="Understands your request and writes the summary.")
        if DEFAULT_MODEL not in chat_models:
            st.caption(f"Default model not installed: `ollama pull {DEFAULT_MODEL}`")

    emb_opts = [NO_EMBED] + embed_models
    emb_idx = next((i for i, m in enumerate(emb_opts) if m.startswith(DEFAULT_EMBED_MODEL)), 0)
    embed_choice = st.selectbox("Semantic matching", emb_opts, index=emb_idx,
                                help=f"Install `ollama pull {DEFAULT_EMBED_MODEL}` for embedding-based matching.")
    embed_model = None if embed_choice == NO_EMBED else embed_choice

    st.divider()
    data_mode = st.radio("Listings", ["Live: Zameen / Zillow", "Demo data (offline)"],
                         help="Live mode searches the sites at runtime. Demo uses synthetic listings.")
    fetch_mode = st.radio("Fetch mode", ["requests", "browser", "browser-visible"], horizontal=True,
                          help="'browser' uses headless Chromium (Playwright). 'browser-visible' opens a real "
                               "Chromium window on this PC – if Zillow shows a check you can complete it yourself.")
    max_pages = st.slider("Result pages per search", 1, 5, DEFAULT_MAX_PAGES,
                          help="~25-40 listings per page. More pages = better price comparisons, slower.")
    strict = st.checkbox("Hide listings far outside budget / bedrooms", value=True)
    want_summary = st.checkbox("AI summary of the top matches", value=False,
                               help="Slow on CPU with reasoning models like deepseek-r1.")

    with st.expander("Ranking weights"):
        weights = {k: st.slider(k.capitalize(), 0.0, 1.0, v, 0.05) for k, v in DEFAULT_WEIGHTS.items()}
    if st.button("Clear page cache"):
        shutil.rmtree(CACHE_DIR, ignore_errors=True)
        st.success("Cache cleared.")


# ---- main ---------------------------------------------------------------------------------
st.title("🏠 HouseHunt AI")
st.markdown("<p style=\"margin-top:-0.8rem;opacity:0.7;font-size:0.9rem\">Copyright (c) 2026 Transys, Pakistan</p>", unsafe_allow_html=True)
st.caption("Describe the home you want in plain English (or Roman Urdu terms like marla, kanal, crore, lakh). "
           "Pakistan searches zameen.com, USA searches zillow.com.")

if "query_text" not in st.session_state:
    st.session_state.query_text = EXAMPLES[0]
cols = st.columns(3)
for i, ex in enumerate(EXAMPLES):
    if cols[i % 3].button(ex, key=f"ex{i}", width="stretch"):
        st.session_state.query_text = ex

query_text = st.text_area("What are you looking for?", key="query_text", height=80)
go = st.button("🔎 Search", type="primary")

if go and query_text.strip():
    with st.spinner(f"Understanding your request with {llm_model or 'the rule-based parser'}…"):
        t0 = time.time()
        q, err = parse_query(query_text.strip(), client if llm_model else None, llm_model)
        st.session_state.parse_secs = time.time() - t0
    st.session_state.q = q
    st.session_state.parse_err = err
    st.session_state.run = True


def _s(v):
    """Text value or None (pandas turns missing text into NaN, which is truthy)."""
    return v if isinstance(v, str) and v.strip() else None


# ---- editable filters ---------------------------------------------------------------------
def filters_form(q: SearchQuery) -> SearchQuery | None:
    with st.expander(f"Understood as ({q.parsed_by}) — edit and re-run if anything is wrong", expanded=True):
        with st.form("filters"):
            c1, c2, c3, c4 = st.columns(4)
            country = c1.selectbox("Country", ["PK", "US"], index=0 if q.country != "US" else 1)
            city = c2.text_input("City", q.city or "")
            state = c3.selectbox("US state", [""] + sorted(US_STATES),
                                 index=([""] + sorted(US_STATES)).index(q.state) if q.state in US_STATES else 0)
            area = c4.text_input("Town / area", q.area or "")
            c5, c6, c7, c8 = st.columns(4)
            purpose = c5.selectbox("Purpose", ["buy", "rent"], index=0 if q.purpose == "buy" else 1)
            ptype = c6.text_input("Property type", q.property_type or "")
            min_p = c7.number_input(f"Min price ({'PKR' if country == 'PK' else 'USD'})", 0.0,
                                    value=float(q.min_price or 0), step=100000.0, format="%.0f")
            max_p = c8.number_input(f"Max price ({'PKR' if country == 'PK' else 'USD'})", 0.0,
                                    value=float(q.max_price or 0), step=100000.0, format="%.0f")
            c9, c10, c11 = st.columns([1, 1, 2])
            beds = c9.number_input("Beds", 0, 20, value=int(q.beds or 0))
            baths = c10.number_input("Baths", 0, 20, value=int(q.baths or 0))
            kw = c11.text_input("Wishes / keywords (comma separated)", ", ".join(q.keywords))
            st.caption(f"Size: {q.min_size_sqft and f'{q.min_size_sqft:,.0f}' or '—'} – "
                       f"{q.max_size_sqft and f'{q.max_size_sqft:,.0f}' or '—'} sq ft   ·   "
                       f"Budget shown as: {format_price(q.min_price, q.currency)} – {format_price(q.max_price, q.currency)}")
            if st.form_submit_button("Re-run with these filters"):
                return SearchQuery(raw=q.raw, country=country, city=city.strip() or None,
                                   state=state or None, area=area.strip() or None, purpose=purpose,
                                   property_type=ptype.strip() or None, min_price=min_p or None,
                                   max_price=max_p or None, beds=beds or None, baths=baths or None,
                                   min_size_sqft=q.min_size_sqft, max_size_sqft=q.max_size_sqft,
                                   keywords=[k.strip() for k in kw.split(",") if k.strip()],
                                   parsed_by="edited")
    return None


@st.cache_data(ttl=1800, show_spinner=False)
def fetch(q_dict: dict, live: bool, pages: int, mode: str):
    q = SearchQuery(**{k: v for k, v in q_dict.items() if k != "currency"})
    if not live:
        r = demo.search(q)
    elif q.country == "US":
        r = zillow.search(q, pages, mode)
    else:
        r = zameen.search(q, pages, mode)
    return [l.to_dict() for l in r.listings], r.urls, r.notes


if "q" in st.session_state:
    q: SearchQuery = st.session_state.q
    if st.session_state.get("parse_err"):
        st.warning(st.session_state.parse_err)
    edited = filters_form(q)
    if edited:
        st.session_state.q = q = edited
        st.session_state.run = True

    if st.session_state.get("run"):
        st.session_state.run = False
        if not q.country or not q.city:
            st.error("Please name a city (e.g. 'Karachi', 'Lahore', 'Austin, TX') so I know which site to search.")
            st.stop()
        site = "demo data" if data_mode.startswith("Demo") else ("zillow.com" if q.country == "US" else "zameen.com")
        with st.spinner(f"Searching {site}… (pages are fetched politely, a couple of seconds apart)"):
            rows, urls, notes = fetch(q.to_dict(), not data_mode.startswith("Demo"), max_pages, fetch_mode)
        listings = [Listing(**r) for r in rows]
        with st.spinner("Scoring matches and estimating fair prices…"):
            df, info = rank(listings, q, client if embed_model else None, embed_model, weights)
            if strict:
                df = apply_strict_filters(df, q)
        st.session_state.results = (df, info, urls, notes, q)

if "results" in st.session_state:
    df, info, urls, notes, rq = st.session_state.results
    for n in notes:
        st.info(n)
    if df.empty:
        st.warning("No listings to show. Loosen the filters, untick 'Hide listings far outside budget', "
                   "or try demo data to check the pipeline.")
        st.stop()

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Listings ranked", len(df))
    m2.metric("Best match", f"{df['match_score'].iloc[0]:.0%}")
    m3.metric("Median price", format_price(df["price"].median(), rq.currency))
    ppsf = df["price_per_sqft"].median()
    m4.metric("Median price / sq ft", format_price(ppsf, rq.currency) if pd.notna(ppsf) else "—")
    st.caption(f"Semantic matching: {info.get('semantic_method')} · Fair price: {info.get('fair_price_method')}")

    tab_top, tab_all, tab_chart = st.tabs(["Top matches", "All results", "Price vs size"])
    with tab_top:
        for _, r in df.head(10).iterrows():
            with st.container(border=True):
                a, b = st.columns([1, 3])
                if _s(r["image"]):
                    a.image(_s(r["image"]), width="stretch")
                else:
                    a.markdown("### 🏠")
                b.markdown(f"**[{r['title']}]({r['url']})**" if _s(r["url"]) not in (None, "", "#") else f"**{r['title']}**")
                b.markdown(f"### {format_price(r['price'], r['currency'])}"
                           + (" /month" if r["purpose"] == "rent" else ""))
                specs = " · ".join(x for x in [
                    f"{int(r['beds'])} bed" if pd.notna(r["beds"]) else None,
                    f"{int(r['baths'])} bath" if pd.notna(r["baths"]) else None,
                    _s(r["size_text"]), _s(r["property_type"]), _s(r["location"])] if x)
                b.caption(specs)
                fair_txt = (f"Fair price ≈ {format_price(r['fair_price'], r['currency'])} → **{r['deal']}**"
                            if pd.notna(r["fair_price"]) else "")
                b.markdown(f"Match **{r['match_score']:.0%}** · location {r['location_s']:.0%} · "
                           f"budget {r['price_s']:.0%} · specs {r['specs_s']:.0%} · text {r['semantic']:.0%}  \n"
                           f"{fair_txt} · median of {int(r['peers'])} nearby: "
                           f"{format_price(r['peer_median_price'], r['currency'])}")

    with tab_all:
        show = df[["match_score", "title", "price", "deal", "fair_price", "beds", "baths", "size_text",
                   "location", "property_type", "source", "url"]].copy()
        st.dataframe(show, width="stretch", hide_index=True, column_config={
            "match_score": st.column_config.ProgressColumn("Match", format="%.2f", min_value=0, max_value=1),
            "price": st.column_config.NumberColumn("Price", format="%,.0f"),
            "fair_price": st.column_config.NumberColumn("Fair price", format="%,.0f"),
            "url": st.column_config.LinkColumn("Link", display_text="open"),
        })
        st.download_button("Download CSV", df.drop(columns=["image"]).to_csv(index=False),
                           file_name="househunt_results.csv", mime="text/csv")

    with tab_chart:
        cd = df.dropna(subset=["price", "size_sqft"])
        if cd.empty:
            st.info("Listings have no size information to chart.")
        else:
            chart = alt.Chart(cd).mark_circle(size=90, opacity=0.8).encode(
                x=alt.X("size_sqft:Q", title="Size (sq ft)"),
                y=alt.Y("price:Q", title=f"Price ({rq.currency})"),
                color=alt.Color("deal:N", title="Value", scale=alt.Scale(
                    domain=["Great value", "Below market", "Fair price", "Above market", "Overpriced", "—"],
                    range=["#1a9850", "#91cf60", "#9e9e9e", "#fc8d59", "#d73027", "#cccccc"])),
                size=alt.Size("match_score:Q", title="Match"),
                tooltip=["title", "location", alt.Tooltip("price:Q", format=",.0f"),
                         alt.Tooltip("fair_price:Q", format=",.0f"), "deal",
                         alt.Tooltip("match_score:Q", format=".0%")],
            ).interactive()
            st.altair_chart(chart, width="stretch")

    if urls:
        with st.expander("Pages searched"):
            for u in urls:
                st.markdown(f"- {u}")

    if want_summary and llm_model:
        key = (id(st.session_state.results), llm_model)
        if st.session_state.get("summary_key") != key:
            with st.spinner(f"{llm_model} is reviewing the top matches…"):
                top = df.head(6)
                top_listings = [Listing(**{k: (None if pd.isna(r[k]) else r[k]) if not isinstance(r[k], str) else r[k]
                                           for k in Listing.__dataclass_fields__}) for _, r in top.iterrows()]
                try:
                    st.session_state.summary = explain_results(client, llm_model, rq, top_listings,
                                                               top.to_dict("records"))
                except Exception as e:
                    st.session_state.summary = f"Summary failed: {e}"
                st.session_state.summary_key = key
        st.subheader("🤖 AI take")
        st.write(st.session_state.summary)
