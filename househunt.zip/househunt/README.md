# HouseHunt AI

Describe the home you want in plain language — *"10 marla house in DHA Phase 6 Lahore under 8 crore, 4 beds, corner"* or *"3 bed 2 bath house in Austin, TX under $550k"* — and the app searches **zameen.com** (Pakistan) or **zillow.com** (USA) live, then ranks every listing by how well it fits your city, town/area, budget and specs, and flags which ones are priced above or below comparable listings.

Everything runs locally: the language model is served by **Ollama** (default `deepseek-r1:7b`, switchable to any model you have pulled).

## Quick start

```bash
# 1. Ollama + models
ollama pull deepseek-r1:7b
ollama pull nomic-embed-text        # optional, better semantic matching
ollama serve                        # if it isn't already running

# 2. App
cd househunt
# Windows: just double-click run.bat instead of the next three lines
python -m venv .venv && .venv\Scripts\activate      # Windows   (Linux/Mac: source .venv/bin/activate)
pip install -r requirements.txt
streamlit run app.py
```

Optional, for browser fetch modes: `pip install playwright && python -m playwright install chromium`

## How it works

```
your sentence ──► Ollama LLM (deepseek-r1:7b / any model) ──► structured filters
                  + rule-based parser (crore, lakh, marla, kanal, $k, M)      │
                                                                               ▼
                         zameen.com  (PK)  /  zillow.com (US)  ◄── live fetch, cached 6 h, 2 s between pages
                                                                               │
                                     listings ──► ML ranking ──► top matches, fair price, chart, CSV
```

**1. Understanding the request (`llm.py`).** The selected Ollama model is asked for JSON matching a schema (country, city, state, town/area, buy/rent, type, price range, beds, baths, size, keywords). `<think>` blocks from reasoning models are stripped. A rule-based parser runs alongside and fills gaps; for crore/lakh figures the rules win, because small models often slip a zero. Every parsed filter is shown in an editable form so you can correct it and re-run.

**2. Live search (`sources/`).**
- *Zameen*: builds URLs like `/Houses_Property/Karachi_D.H.A_DHA_Phase_6-1483-1.html?price_max=…&beds_in=…`. Town/area names are resolved to Zameen location IDs by reading location links on Zameen's own pages (drilling one level, e.g. Karachi → DHA Defence → DHA Phase 6) and remembered in `.cache/zameen_locations.json`. Listing cards plus the page's schema.org data give price, size (marla/kanal/sq yd → sq ft), beds, baths, type and description.
- *Zillow*: builds `/austin-tx/` or `/hyde-park-austin-tx/rentals/` URLs with a `searchQueryState` filter, and reads results (including Zestimate / rent Zestimate) from the page's embedded JSON.
- *Demo data*: synthetic listings for offline testing.

**3. Ranking (`ranking.py`).** Each listing gets five scores, combined with weights you can tune in the sidebar:

| Score | Method |
|---|---|
| Semantic | cosine similarity of Ollama embeddings (`nomic-embed-text`), TF-IDF if none installed |
| Location | fuzzy match of your town/area; phase/sector/block numbers must agree |
| Budget | 1 inside your range, smooth decay outside (over budget penalised harder) |
| Specs | beds, baths, size, property type, wished-for features |
| Value | price ÷ fair price |

*Fair price* comes from a RandomForest trained on the other listings in the same search (size, beds, baths, type, location target-encoding), using 5-fold out-of-fold predictions so a listing never prices itself; with fewer than 20 listings it falls back to price-per-sq-ft of comparables. For Zillow it's blended with the Zestimate. Labels: Great value / Below market / Fair price / Above market / Overpriced. A plot is never ranked as a house: wrong property category is a hard penalty.

## Fetch modes

| Mode | When |
|---|---|
| `requests` | Default, fast. Works well for Zameen. |
| `browser` | Headless Chromium. Use if a site stops returning results to plain requests. |
| `browser-visible` | Opens a real Chromium window on your PC. Useful for Zillow: if it shows a "press and hold" check, you complete it yourself and the app reads the results. |

Zillow is protected against automated traffic and often answers HTTP 403, especially from cloud servers. From a home connection it varies. The app never tries to solve or bypass bot checks; it reports the block and continues. Use searches at personal scale, respect each site's terms of use, and don't redistribute scraped data.

## Configuration

Environment variables (see `config.py`): `OLLAMA_URL`, `HH_MODEL` (default `deepseek-r1:7b`), `HH_EMBED_MODEL`, `HH_REQUEST_DELAY` (seconds between pages, default 2), `HH_MAX_PAGES`, `HH_CACHE_TTL`.

To add a Pakistani city, open it on zameen.com and copy the number from the URL (e.g. `/Homes/Multan-15-1.html` → 15) into `ZAMEEN_CITY_IDS` in `units.py`. Lahore (1), Karachi (2), Islamabad (3) and Rawalpindi (41) are included.

## Files

```
app.py              Streamlit UI (model picker, query, editable filters, results, chart, CSV)
llm.py              Ollama client, NL → filters (LLM + rules), AI summary
ranking.py          Semantic + structured scoring, RandomForest fair-price model
units.py            Price (crore/lakh/arab/$k/M) and area (marla/kanal/sq yd/sqft) parsing
sources/zameen.py   Live zameen.com search + location resolver
sources/zillow.py   Live zillow.com search
sources/demo.py     Synthetic listings
sources/base.py     Rate-limited, cached fetching; optional Playwright browser
tests/test_core.py  Offline tests:  python -m pytest -q
LICENSE.txt         Freeware license
```

## Tips

- `deepseek-r1:7b` thinks before answering, so parsing takes 10–60 s on CPU. For snappier parsing pick `llama3.2:3b` or `qwen2.5:7b` in the sidebar; keep deepseek-r1 for the AI summary.
- More result pages = better fair-price estimates (the model learns from more comparables).
- Pages are cached for 6 hours; "Clear page cache" in the sidebar forces fresh results.
