#!/usr/bin/env bash
# One-click start on Linux / macOS. First run creates a virtual environment and installs packages.
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt
else
  source .venv/bin/activate
fi
streamlit run app.py
