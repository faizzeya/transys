"""Ollama client: model discovery, natural-language query parsing, embeddings, explanations.

Talks to Ollama's REST API directly (no extra SDK), so any Ollama version >= 0.5 works.
Reasoning models such as deepseek-r1 emit <think>...</think> blocks; those are stripped.
"""
from __future__ import annotations

import json
import re
from typing import Optional

import requests

from config import LLM_TIMEOUT, OLLAMA_URL
from models import Listing, SearchQuery
from units import (PK_CITIES, STATE_NAME_TO_CODE, US_CITY_STATE, US_STATES, format_price,
                   parse_area_sqft, parse_int, parse_price)

QUERY_SCHEMA = {
    "type": "object",
    "properties": {
        "country": {"type": ["string", "null"], "enum": ["PK", "US", None]},
        "city": {"type": ["string", "null"]},
        "state": {"type": ["string", "null"]},
        "area": {"type": ["string", "null"]},
        "purpose": {"type": "string", "enum": ["buy", "rent"]},
        "property_type": {"type": ["string", "null"]},
        "min_price": {"type": ["number", "null"]},
        "max_price": {"type": ["number", "null"]},
        "beds": {"type": ["integer", "null"]},
        "baths": {"type": ["integer", "null"]},
        "min_size": {"type": ["string", "null"]},
        "max_size": {"type": ["string", "null"]},
        "keywords": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["country", "city", "area", "purpose", "min_price", "max_price", "beds", "keywords"],
}

SYSTEM_PROMPT = """You convert a home-search request into JSON filters for zameen.com (Pakistan) and zillow.com (USA).
Rules:
- country: "PK" for Pakistani cities or PKR/crore/lakh/marla/kanal; "US" for US cities/states or dollars.
- city: the city only (e.g. "Karachi", "Austin"). state: 2-letter US state code if known, else null.
- area: the town / neighbourhood / society / phase / block inside the city (e.g. "DHA Phase 6", "Bahria Town", "Gulshan-e-Iqbal", "Hyde Park"), else null.
- purpose: "rent" if they want to rent/lease, else "buy".
- property_type: house, apartment, flat, condo, townhouse, plot, villa, penthouse, or null.
- min_price / max_price: plain numbers in the local currency. 1 crore = 10000000, 1 lakh = 100000, 1 arab = 1000000000, "500k" = 500000, "1.2M" = 1200000. "under X" -> max_price X; "around X" -> min 0.85X, max 1.15X.
- beds / baths: integers if stated.
- min_size / max_size: keep the original unit as text, e.g. "10 marla", "1 kanal", "240 sq yd", "2000 sqft".
- keywords: other wishes (e.g. "corner", "pool", "near school", "new construction", "furnished").
Return ONLY the JSON object."""


def strip_think(text: str) -> str:
    return re.sub(r"<think>.*?</think>", "", text or "", flags=re.S).strip()


def extract_json(text: str) -> Optional[dict]:
    text = strip_think(text)
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    try:
        return json.loads(text)
    except Exception:
        pass
    m = re.search(r"\{.*\}", text, flags=re.S)
    if m:
        try:
            return json.loads(m.group())
        except Exception:
            return None
    return None


class OllamaClient:
    def __init__(self, base_url: str = OLLAMA_URL, timeout: int = LLM_TIMEOUT):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    # -- discovery --------------------------------------------------------------
    def available(self) -> bool:
        try:
            return requests.get(f"{self.base_url}/api/version", timeout=3).ok
        except requests.RequestException:
            return False

    def list_models(self) -> list[str]:
        try:
            r = requests.get(f"{self.base_url}/api/tags", timeout=5)
            r.raise_for_status()
            return sorted(m["name"] for m in r.json().get("models", []))
        except requests.RequestException:
            return []

    @staticmethod
    def is_embedding_model(name: str) -> bool:
        return any(k in name.lower() for k in ("embed", "bge", "minilm", "e5-", "gte"))

    # -- generation -------------------------------------------------------------
    def chat(self, model: str, messages: list[dict], schema: Optional[dict] = None,
             temperature: float = 0.0) -> str:
        payload = {
            "model": model,
            "messages": messages,
            "stream": False,
            "options": {"temperature": temperature, "num_ctx": 4096},
        }
        if schema is not None:
            payload["format"] = schema
            payload["think"] = False   # newer Ollama: skip the reasoning trace when we need JSON
        r = requests.post(f"{self.base_url}/api/chat", json=payload, timeout=self.timeout)
        if r.status_code == 400 and "think" in r.text:      # model/version without think support
            payload.pop("think", None)
            r = requests.post(f"{self.base_url}/api/chat", json=payload, timeout=self.timeout)
        r.raise_for_status()
        return r.json().get("message", {}).get("content", "")

    def embed(self, model: str, texts: list[str]) -> Optional[list[list[float]]]:
        try:
            r = requests.post(f"{self.base_url}/api/embed", json={"model": model, "input": texts},
                              timeout=self.timeout)
            r.raise_for_status()
            return r.json().get("embeddings")
        except requests.RequestException:
            return None


# ---- natural language -> SearchQuery ---------------------------------------------------

def parse_query(query: str, client: Optional[OllamaClient] = None, model: Optional[str] = None
                ) -> tuple[SearchQuery, Optional[str]]:
    """Returns (SearchQuery, error_message). Uses the LLM when possible, rules otherwise,
    and always merges both so a weak small model can't drop obvious facts."""
    rules = rule_based_parse(query)
    if client is None or not model:
        return rules, None
    try:
        content = client.chat(model, [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": query},
        ], schema=QUERY_SCHEMA)
        data = extract_json(content)
        if not data:
            return rules, f"{model} did not return valid JSON; used rule-based parser."
        llm_q = _from_llm_dict(data, query)
        return _merge(llm_q, rules), None
    except requests.RequestException as e:
        return rules, f"Ollama call failed ({e.__class__.__name__}); used rule-based parser."


def _from_llm_dict(d: dict, raw: str) -> SearchQuery:
    q = SearchQuery(raw=raw, parsed_by="llm")
    q.country = (d.get("country") or None)
    q.country = q.country.upper() if isinstance(q.country, str) else None
    q.city = _clean(d.get("city"))
    st = _clean(d.get("state"))
    if st:
        st = st.upper() if len(st) == 2 else STATE_NAME_TO_CODE.get(st.lower())
    q.state = st if st in US_STATES else None
    q.area = _clean(d.get("area"))
    q.purpose = "rent" if str(d.get("purpose", "")).lower().startswith("rent") else "buy"
    q.property_type = _clean(d.get("property_type"))
    q.min_price = parse_price(d.get("min_price")) or None
    q.max_price = parse_price(d.get("max_price")) or None
    q.beds = parse_int(d.get("beds"))
    q.baths = parse_int(d.get("baths"))
    q.min_size_sqft = parse_area_sqft(d.get("min_size"))
    q.max_size_sqft = parse_area_sqft(d.get("max_size"))
    q.keywords = [k for k in (d.get("keywords") or []) if isinstance(k, str) and k.strip()][:10]
    return _finalise(q)


def _clean(v):
    if v is None:
        return None
    v = str(v).strip()
    return None if v.lower() in ("", "null", "none", "n/a", "any") else v


def _merge(llm_q: SearchQuery, rules: SearchQuery) -> SearchQuery:
    """Prefer LLM values; fill gaps from rules. Rules win on price when they found an explicit
    crore/lakh figure, because small models often get Pakistani number words wrong."""
    for f in ("country", "city", "state", "area", "property_type", "beds", "baths",
              "min_size_sqft", "max_size_sqft"):
        if getattr(llm_q, f) in (None, "") and getattr(rules, f) not in (None, ""):
            setattr(llm_q, f, getattr(rules, f))
    if re.search(r"crore|lakh|lac|arab", rules.raw, re.I):
        if rules.min_price or rules.max_price:
            llm_q.min_price, llm_q.max_price = rules.min_price, rules.max_price
    else:
        llm_q.min_price = llm_q.min_price or rules.min_price
        llm_q.max_price = llm_q.max_price or rules.max_price
    if rules.purpose == "rent":
        llm_q.purpose = "rent"
    llm_q.keywords = list(dict.fromkeys(llm_q.keywords + rules.keywords))
    return _finalise(llm_q)


def _finalise(q: SearchQuery) -> SearchQuery:
    if q.city:
        q.city = q.city.strip().title()
        cl = q.city.lower()
        if cl in PK_CITIES:
            q.country = "PK"
        elif cl in US_CITY_STATE:
            q.country = "US"
            q.state = q.state or US_CITY_STATE[cl]
    if q.state and not q.country:
        q.country = "US"
    if q.min_price and q.max_price and q.min_price > q.max_price:
        q.min_price, q.max_price = q.max_price, q.min_price
    return q


# ---- rule-based fallback parser -------------------------------------------------------
_PRICE_TOKEN = r"(?:\$\s*)?\d[\d,]*(?:\.\d+)?\s*(?:arab|crores?|cr|lakhs?|lacs?|million|mil|mn|billion|bn|thousand|k|m)?\b"


def rule_based_parse(text: str) -> SearchQuery:
    q = SearchQuery(raw=text, parsed_by="rules")
    t = text.lower()

    for c in sorted(PK_CITIES, key=len, reverse=True):
        if re.search(rf"\b{re.escape(c)}\b", t):
            q.city, q.country = c.title(), "PK"
            break
    if not q.city:
        for c in sorted(US_CITY_STATE, key=len, reverse=True):
            if re.search(rf"\b{re.escape(c)}\b", t):
                q.city, q.country, q.state = c.title(), "US", US_CITY_STATE[c]
                break
    m = re.search(r",\s*([A-Z]{2})\b", text)
    if m and m.group(1) in US_STATES:
        q.state, q.country = m.group(1), "US"
    for name, code in STATE_NAME_TO_CODE.items():
        if re.search(rf"\b{name}\b", t):
            q.state, q.country = code, "US"
            break
    if not q.country:
        if re.search(r"crore|lakh|lac\b|marla|kanal|pkr|rs\.?\s", t):
            q.country = "PK"
        elif "$" in t or "usd" in t or "dollar" in t:
            q.country = "US"

    q.purpose = "rent" if re.search(r"\b(rent|rental|lease|to let)\b", t) else "buy"
    for pt in ("penthouse", "townhouse", "apartment", "condo", "flat", "villa", "plot", "bungalow", "house", "home"):
        if re.search(rf"\b{pt}s?\b", t):
            q.property_type = "house" if pt in ("home", "bungalow") else pt
            break

    m = re.search(r"(\d+)\s*(?:-|\s)?(?:bed|bd|br|bedroom|room)s?\b", t)
    q.beds = int(m.group(1)) if m else None
    m = re.search(r"(\d+)\s*(?:-|\s)?(?:bath|ba|bathroom|washroom)s?\b", t)
    q.baths = int(m.group(1)) if m else None

    m = re.search(rf"between\s+({_PRICE_TOKEN})\s+(?:and|to|-)\s+({_PRICE_TOKEN})", t) or \
        re.search(rf"({_PRICE_TOKEN})\s*(?:-|to)\s*({_PRICE_TOKEN})", t)
    if m and _looks_like_price(m.group(2)) and (_looks_like_price(m.group(1)) or re.search(r"[a-z$]", m.group(2))):
        a, b = _price_with_shared_unit(m.group(1), m.group(2))
        q.min_price, q.max_price = a, b
    else:
        m = re.search(rf"(?:under|below|less than|max(?:imum)?|upto|up to|within|budget(?: of)?)\s+({_PRICE_TOKEN})", t)
        if m:
            q.max_price = parse_price(m.group(1))
        m2 = re.search(rf"(?:above|over|more than|min(?:imum)?|at least|starting)\s+({_PRICE_TOKEN})", t)
        if m2 and _looks_like_price(m2.group(1)):
            q.min_price = parse_price(m2.group(1))
        m3 = re.search(rf"(?:around|about|approx(?:imately)?|~)\s+({_PRICE_TOKEN})", t)
        if m3 and not (q.min_price or q.max_price):
            p = parse_price(m3.group(1))
            if p:
                q.min_price, q.max_price = p * 0.85, p * 1.15

    m = re.search(r"\d+(?:\.\d+)?\s*(?:kanal|marla|sq\.?\s*yd|sqyd|yards?|gaz|sq\.?\s*ft|sqft|square feet)", t)
    if m:
        size = parse_area_sqft(m.group())
        if size:
            q.min_size_sqft, q.max_size_sqft = size * 0.9, size * 1.1

    m = re.search(r"\b(?:in|at|near)\s+((?:dha|bahria|gulshan|gulberg|clifton|defence|model town|johar|"
                  r"north nazimabad|pechs|scheme|phase|sector|block|[a-z]-\d+)[\w\s\-]*?)"
                  r"(?=,|\s+(?:karachi|lahore|islamabad|rawalpindi|under|below|with|for|around|between)\b|$)", t)
    if m:
        q.area = m.group(1).strip().title()

    q.keywords = [k for k in ("corner", "pool", "garden", "furnished", "basement", "garage", "park facing",
                              "new construction", "renovated", "lawn", "servant quarter", "near school",
                              "gated", "waterfront", "view")
                  if k in t]
    return _finalise(q)


def _looks_like_price(tok: str) -> bool:
    tok = tok.strip().lower()
    return "$" in tok or bool(re.search(r"[a-z]", tok)) or parse_price(tok) and parse_price(tok) >= 1000


def _price_with_shared_unit(a: str, b: str) -> tuple:
    """'1.5 to 2 crore' -> both in crore."""
    unit_b = re.search(r"[a-z]+$", b.strip())
    if unit_b and not re.search(r"[a-z]", a):
        a = f"{a.strip()} {unit_b.group()}"
    return parse_price(a), parse_price(b)


# ---- explanation ------------------------------------------------------------------------

def explain_results(client: OllamaClient, model: str, q: SearchQuery, top: list[Listing],
                    extra: list[dict]) -> str:
    lines = []
    for i, (l, x) in enumerate(zip(top, extra), 1):
        lines.append(
            f"{i}. {l.title} | {l.location or ''}, {l.city or ''} | {format_price(l.price, l.currency)} | "
            f"{l.beds or '?'} bed / {l.baths or '?'} bath | {l.size_text or ''} | "
            f"match {x['match_score']:.0%} | value: {x['deal']}"
        )
    prompt = (f"A user is looking for: \"{q.raw}\"\n\nTop matching listings:\n" + "\n".join(lines) +
              "\n\nIn under 150 words, say which 2-3 are the best fit and why, and point out any that "
              "look under- or over-priced compared with the others. Be concrete; no preamble.")
    out = client.chat(model, [{"role": "user", "content": prompt}], temperature=0.3)
    return strip_think(out)
