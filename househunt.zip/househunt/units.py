"""Parsing of prices, areas and locations as they appear on Zameen, Zillow and in free text."""
from __future__ import annotations

import re
from typing import Optional

# ---- Pakistani + US price words -------------------------------------------------
_PRICE_WORDS = {
    "arab": 1e9, "crore": 1e7, "cr": 1e7, "crores": 1e7,
    "lakh": 1e5, "lac": 1e5, "lacs": 1e5, "lakhs": 1e5, "l": 1e5,
    "million": 1e6, "mn": 1e6, "m": 1e6, "mil": 1e6,
    "billion": 1e9, "bn": 1e9, "b": 1e9,
    "thousand": 1e3, "k": 1e3,
}
_PRICE_RE = re.compile(
    r"(?P<num>\d[\d,]*(?:\.\d+)?)\s*(?P<unit>arab|crores?|cr|lakhs?|lacs?|lac|million|mil|mn|billion|bn|thousand|[kmbl])?\b",
    re.I,
)


def parse_price(text) -> Optional[float]:
    """'PKR 2.5 Crore' -> 25_000_000 ; '$450,000' -> 450000 ; '1.2M' -> 1_200_000 ; '75 Lakh' -> 7_500_000."""
    if text is None:
        return None
    if isinstance(text, (int, float)):
        return float(text)
    s = str(text).replace(" ", " ").strip()
    if not s:
        return None
    total, found = 0.0, False
    # Zameen sometimes writes "1 Crore 20 Lakh" – sum all parts that carry a unit
    for m in _PRICE_RE.finditer(s):
        num = float(m.group("num").replace(",", ""))
        unit = (m.group("unit") or "").lower()
        if unit:
            total += num * _PRICE_WORDS[unit]
            found = True
        elif not found and num > 0:
            total = num
            found = True
            break
    return total if found else None


def format_price(value: Optional[float], currency: str) -> str:
    if value is None:
        return "—"
    if currency == "PKR":
        if value >= 1e9:
            return f"PKR {value/1e9:.2f} Arab"
        if value >= 1e7:
            return f"PKR {value/1e7:.2f} Crore"
        if value >= 1e5:
            return f"PKR {value/1e5:.2f} Lakh"
        return f"PKR {value:,.0f}"
    if value >= 1e6:
        return f"${value/1e6:.2f}M"
    return f"${value:,.0f}"


# ---- Areas ----------------------------------------------------------------------
# Zameen uses 1 Marla = 225 sq ft (its site-wide convention), 1 Kanal = 20 Marla.
_AREA_UNITS = {
    "kanal": 4500.0, "kanals": 4500.0,
    "marla": 225.0, "marlas": 225.0,
    "sq. yd.": 9.0, "sq yd": 9.0, "sq. yd": 9.0, "sqyd": 9.0, "square yards": 9.0, "yards": 9.0, "yd": 9.0, "gaz": 9.0,
    "sq. ft.": 1.0, "sq ft": 1.0, "sqft": 1.0, "sq. ft": 1.0, "square feet": 1.0, "ft": 1.0,
    "sq. m.": 10.7639, "sq m": 10.7639, "square meters": 10.7639, "sqm": 10.7639,
    "acre": 43560.0, "acres": 43560.0,
}
_AREA_RE = re.compile(
    r"(?P<num>\d[\d,]*(?:\.\d+)?)\s*(?P<unit>kanals?|marlas?|sq\.?\s*yd\.?|sqyd|square yards|yards|yd|gaz|"
    r"sq\.?\s*ft\.?|sqft|square feet|sq\.?\s*m\.?|sqm|square meters|acres?)",
    re.I,
)


def parse_area_sqft(text) -> Optional[float]:
    """'10 Marla' -> 2250 ; '1 Kanal' -> 4500 ; '240 Sq. Yd.' -> 2160 ; '1,850 sqft' -> 1850."""
    if text is None:
        return None
    if isinstance(text, (int, float)):
        return float(text)
    m = _AREA_RE.search(str(text))
    if not m:
        return None
    num = float(m.group("num").replace(",", ""))
    unit = re.sub(r"\s+", " ", m.group("unit").lower().strip())
    factor = _AREA_UNITS.get(unit)
    if factor is None:
        key = unit.replace(".", "").replace(" ", "")
        factor = {"sqyd": 9.0, "sqft": 1.0, "sqm": 10.7639}.get(key, 1.0)
    return num * factor


def parse_int(text) -> Optional[int]:
    if text is None:
        return None
    if isinstance(text, (int, float)):
        return int(text)
    m = re.search(r"\d+", str(text))
    return int(m.group()) if m else None


# ---- Places -----------------------------------------------------------------------
# Zameen city IDs used in URLs like /Homes/Karachi-2-1.html. Lahore, Karachi, Islamabad and
# Rawalpindi are confirmed; add more by opening the city on zameen.com and copying the ID.
ZAMEEN_CITY_IDS = {
    "lahore": 1, "karachi": 2, "islamabad": 3, "rawalpindi": 41,
}
PK_CITIES = set(ZAMEEN_CITY_IDS) | {
    "multan", "faisalabad", "peshawar", "gujranwala", "sialkot", "abbottabad", "bahawalpur",
    "sargodha", "sahiwal", "murree", "quetta", "hyderabad", "attock",
}
US_STATES = {
    "AL": "alabama", "AK": "alaska", "AZ": "arizona", "AR": "arkansas", "CA": "california",
    "CO": "colorado", "CT": "connecticut", "DE": "delaware", "FL": "florida", "GA": "georgia",
    "HI": "hawaii", "ID": "idaho", "IL": "illinois", "IN": "indiana", "IA": "iowa", "KS": "kansas",
    "KY": "kentucky", "LA": "louisiana", "ME": "maine", "MD": "maryland", "MA": "massachusetts",
    "MI": "michigan", "MN": "minnesota", "MS": "mississippi", "MO": "missouri", "MT": "montana",
    "NE": "nebraska", "NV": "nevada", "NH": "new hampshire", "NJ": "new jersey", "NM": "new mexico",
    "NY": "new york", "NC": "north carolina", "ND": "north dakota", "OH": "ohio", "OK": "oklahoma",
    "OR": "oregon", "PA": "pennsylvania", "RI": "rhode island", "SC": "south carolina",
    "SD": "south dakota", "TN": "tennessee", "TX": "texas", "UT": "utah", "VT": "vermont",
    "VA": "virginia", "WA": "washington", "WV": "west virginia", "WI": "wisconsin", "WY": "wyoming",
    "DC": "district of columbia",
}
STATE_NAME_TO_CODE = {v: k for k, v in US_STATES.items()}
# Common US cities so "house in Austin" works without a state
US_CITY_STATE = {
    "new york": "NY", "los angeles": "CA", "chicago": "IL", "houston": "TX", "phoenix": "AZ",
    "philadelphia": "PA", "san antonio": "TX", "san diego": "CA", "dallas": "TX", "austin": "TX",
    "san jose": "CA", "jacksonville": "FL", "fort worth": "TX", "columbus": "OH", "charlotte": "NC",
    "san francisco": "CA", "indianapolis": "IN", "seattle": "WA", "denver": "CO", "boston": "MA",
    "nashville": "TN", "detroit": "MI", "portland": "OR", "las vegas": "NV", "atlanta": "GA",
    "miami": "FL", "tampa": "FL", "orlando": "FL", "tulsa": "OK", "oklahoma city": "OK",
    "minneapolis": "MN", "raleigh": "NC", "sacramento": "CA", "kansas city": "MO", "plano": "TX",
    "irvine": "CA", "fremont": "CA", "sugar land": "TX", "frisco": "TX", "naperville": "IL",
}


def slug(text: str, sep: str = "-") -> str:
    return re.sub(r"[^a-z0-9]+", sep, text.lower()).strip(sep)
