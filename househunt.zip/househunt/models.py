"""Plain data classes shared by every module."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Optional


@dataclass
class SearchQuery:
    raw: str = ""
    country: Optional[str] = None          # "PK" or "US"
    city: Optional[str] = None
    state: Optional[str] = None            # US state code, e.g. "TX"
    area: Optional[str] = None             # town / neighbourhood / society / phase
    purpose: str = "buy"                   # "buy" or "rent"
    property_type: Optional[str] = None    # house, apartment, condo, townhouse, plot ...
    min_price: Optional[float] = None      # in local currency units (PKR or USD)
    max_price: Optional[float] = None
    beds: Optional[int] = None
    baths: Optional[int] = None
    min_size_sqft: Optional[float] = None
    max_size_sqft: Optional[float] = None
    keywords: list[str] = field(default_factory=list)  # "corner", "pool", "near park" ...
    parsed_by: str = "rules"               # which parser produced this

    @property
    def currency(self) -> str:
        return "PKR" if self.country == "PK" else "USD"

    def to_dict(self) -> dict:
        d = asdict(self)
        d["currency"] = self.currency
        return d


@dataclass
class Listing:
    source: str                            # "zameen" / "zillow" / "demo"
    listing_id: str
    title: str
    url: str
    price: Optional[float]
    currency: str
    city: Optional[str] = None
    location: Optional[str] = None         # area / address text
    beds: Optional[int] = None
    baths: Optional[int] = None
    size_sqft: Optional[float] = None
    size_text: Optional[str] = None        # as shown on the site, e.g. "10 Marla"
    property_type: Optional[str] = None
    description: str = ""
    image: Optional[str] = None
    market_estimate: Optional[float] = None  # e.g. Zillow Zestimate / rent Zestimate
    purpose: str = "buy"

    def text_blob(self) -> str:
        parts = [self.title, self.property_type or "", self.location or "", self.city or "",
                 f"{self.beds} bedrooms" if self.beds else "",
                 f"{self.baths} bathrooms" if self.baths else "",
                 self.size_text or "", self.description[:600]]
        return " | ".join(p for p in parts if p)

    def to_dict(self) -> dict:
        return asdict(self)
