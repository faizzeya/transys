"""Central configuration. Every value can be overridden with an environment variable."""
import os
import sys
from pathlib import Path

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
DEFAULT_MODEL = os.getenv("HH_MODEL", "deepseek-r1:7b")
# Optional embedding model for semantic matching ("ollama pull nomic-embed-text").
# If it is not installed the app falls back to TF-IDF automatically.
DEFAULT_EMBED_MODEL = os.getenv("HH_EMBED_MODEL", "nomic-embed-text")
LLM_TIMEOUT = int(os.getenv("HH_LLM_TIMEOUT", "300"))

# Scraping etiquette
REQUEST_DELAY_SEC = float(os.getenv("HH_REQUEST_DELAY", "2.0"))   # pause between page requests
HTTP_TIMEOUT = int(os.getenv("HH_HTTP_TIMEOUT", "25"))
DEFAULT_MAX_PAGES = int(os.getenv("HH_MAX_PAGES", "2"))

# In the packaged .exe the program folder may be read-only, so cache in the user's home folder.
_default_cache = (Path.home() / ".househunt" / "cache") if getattr(sys, "frozen", False) \
    else Path(__file__).parent / ".cache"
CACHE_DIR = Path(os.getenv("HH_CACHE_DIR", _default_cache))
CACHE_TTL_SEC = int(os.getenv("HH_CACHE_TTL", str(6 * 3600)))

USER_AGENT = os.getenv(
    "HH_USER_AGENT",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/129.0 Safari/537.36",
)
