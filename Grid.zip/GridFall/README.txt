GRIDFALL 1.0
A falling-block puzzle game for Windows 10 and 11
Published by Transys - freeware (see LICENSE.txt)

TO PLAY
Double-click GridFall.exe. There is nothing to install.

If Windows shows "Windows protected your PC", click "More info" and then
"Run anyway". This appears for any new program that is not code-signed.

MODES
Marathon   Endless. Speed rises every 10 lines.
Sprint     Clear 40 lines as fast as possible.
Ultra      Highest score in three minutes.
Survival   Garbage rows rise from below; cleared lines cancel them.
Master     Pieces land instantly. Clear 200 lines.

CONTROLS
Left / Right      Move (hold to slide)
Down              Soft drop
Space             Hard drop
Up or X           Rotate clockwise
Z or Ctrl         Rotate counter-clockwise
A                 Rotate 180 degrees
C or Shift        Hold piece
P or Esc          Pause
M                 Sound on / off
F11 or Alt+Enter  Full screen

Settings and high scores are kept in %AppData%\GridFall\gridfall.sav.
To uninstall, delete GridFall.exe and that folder.
