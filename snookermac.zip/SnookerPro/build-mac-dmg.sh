#!/bin/bash
# Builds Snooker Pro for Mac, signs it with your Developer ID, notarizes it with
# Apple and packages it as SnookerPro-Mac.dmg, ready to put on your website.
#
# One-time setup (see README "Mac version"):
#   1. Xcode > Settings > Accounts > Manage Certificates > + > "Developer ID Application"
#   2. Create an app-specific password at account.apple.com, then run:
#        xcrun notarytool store-credentials snooker-notary \
#          --apple-id "you@example.com" --team-id "YOURTEAMID" --password "xxxx-xxxx-xxxx-xxxx"
#
# Usage:  ./build-mac-dmg.sh YOURTEAMID
set -euo pipefail

TEAM_ID="${1:?Usage: ./build-mac-dmg.sh YOUR_TEAM_ID}"
NOTARY_PROFILE="${NOTARY_PROFILE:-snooker-notary}"
APP_NAME="Snooker Pro"
DMG="SnookerPro-Mac.dmg"
BUILD="build"

cd "$(dirname "$0")"
rm -rf "$BUILD" "$DMG"
mkdir -p "$BUILD"

echo "==> Archiving"
xcodebuild -project SnookerPro.xcodeproj -scheme "SnookerPro macOS" -configuration Release \
  -archivePath "$BUILD/SnookerPro-mac.xcarchive" DEVELOPMENT_TEAM="$TEAM_ID" archive

echo "==> Exporting with Developer ID signing"
cat > "$BUILD/ExportOptions.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>method</key><string>developer-id</string>
  <key>teamID</key><string>$TEAM_ID</string>
  <key>signingStyle</key><string>automatic</string>
</dict>
</plist>
EOF
xcodebuild -exportArchive -archivePath "$BUILD/SnookerPro-mac.xcarchive" \
  -exportOptionsPlist "$BUILD/ExportOptions.plist" -exportPath "$BUILD/export"

echo "==> Creating disk image"
STAGE="$BUILD/dmg"
mkdir -p "$STAGE"
cp -R "$BUILD/export/$APP_NAME.app" "$STAGE/"
ln -s /Applications "$STAGE/Applications"
hdiutil create -volname "$APP_NAME" -srcfolder "$STAGE" -ov -format UDZO "$DMG"

IDENTITY=$(security find-identity -v -p codesigning | grep "Developer ID Application" | grep "$TEAM_ID" | head -1 | sed -E 's/.*"(.*)"/\1/')
codesign --sign "$IDENTITY" --timestamp "$DMG"

echo "==> Notarizing (usually takes a few minutes)"
xcrun notarytool submit "$DMG" --keychain-profile "$NOTARY_PROFILE" --wait
xcrun stapler staple "$DMG"

echo "==> Checking Gatekeeper accepts it"
spctl --assess --type open --context context:primary-signature -v "$DMG"

echo "Done: $DMG — upload it to your website."
