# Snooker Pro for iPhone, iPad and Mac

Developed by Transys, Pakistan. CEO Faiz ul Haque Zeya.

A full 15-red snooker game written in Swift with SpriteKit and SwiftUI. It needs no third-party libraries.

## Features
- Full-size table proportions, 15 reds and 6 colours on their official spots, baulk line and D.
- Snooker rules: red then colour, colours re-spotted while reds remain, then the final clearance from yellow to black. Includes fouls (wrong ball first, missing, wrong pot, in-off) with a minimum of 4 penalty points, ball in hand in the D after an in-off, and a re-spotted black when scores are tied.
- Cue spin: follow, screw and side.
- An aim line, a ghost ball, and the predicted path of the object ball.
- A computer opponent with Easy, Medium and Hard levels, plus a two-player mode.
- Scores, current break, highest break, reds left and points remaining.
- Sound effects, haptics, landscape layout for iPhone and iPad, and an app icon.

The free-ball and "miss" rules are not enforced, as in most casual snooker games.

## Build and run (needs a Mac)
1. Install **Xcode** from the Mac App Store. Use Xcode 15 or later.
2. Open `SnookerPro.xcodeproj`.
3. Select the **SnookerPro** target, then open **Signing & Capabilities**. Choose your **Team**, which is your Apple Developer account. If needed, change the Bundle Identifier from `com.transys.snookerpro` to a unique value.
4. Choose an iPhone simulator or your own iPhone, then press **Run** (⌘R).

## Publish to the App Store
1. Enrol in the Apple Developer Program at developer.apple.com. It costs 99 USD per year.
2. In **App Store Connect**, go to **Apps**, click **+**, and choose **New App**. Use the same bundle ID as the project.
3. Add the store listing:
   - Name and subtitle.
   - Description.
   - Screenshots: take them in the simulator with ⌘S, for example on an iPhone 6.9" and an iPad 13".
   - Privacy policy URL.
   - Category: Games › Sports.
   - Age rating.
   - Price: Free.
   - Privacy "Data Not Collected". The app collects no data.
4. Upload the build from Xcode:
   - Select **Any iOS Device** as the destination.
   - Choose **Product › Archive**.
   - In the Organizer, choose **Distribute App**, then **App Store Connect**, then **Upload**.
5. Select the uploaded build and click **Submit for Review**.

Notes:
- The app uses no encryption. `ITSAppUsesNonExemptEncryption = NO` is already in `Info.plist`, so the export-compliance question is answered automatically.
- iPhones cannot install apps downloaded from a website. Your website should link to the App Store page. The included `snooker.html` landing page does this.

## Mac version
The project has two targets that share all the game code. **SnookerPro** is for iPhone and iPad. **SnookerPro macOS** is for Macs running macOS 13 Ventura or later, on both Apple Silicon and Intel.

On a Mac you play with the mouse or trackpad. The keyboard also works: Space shoots, the Left and Right arrows fine-aim (hold Shift for bigger steps), and the Up and Down arrows change power.

To run it, select the **SnookerPro macOS** scheme at the top of Xcode, choose **My Mac**, and press Run.

### Distributing it from your website (no App Store)
Mac users can download and run the app straight from your website. To open without security warnings, it must be signed with a **Developer ID** certificate and **notarized** by Apple. Both are included in the 99 USD Apple Developer membership.

One-time setup:
1. Create the certificate: in Xcode go to **Settings › Accounts › Manage Certificates › + › Developer ID Application**. Only the account holder can create this certificate.
2. Create an app-specific password at account.apple.com, under Sign-In and Security.
3. Save the password for the notary tool:
   `xcrun notarytool store-credentials snooker-notary --apple-id YOUR_APPLE_ID --team-id YOUR_TEAM_ID --password APP_SPECIFIC_PASSWORD`

Each release:
1. In Terminal, in this folder, run `./build-mac-dmg.sh YOUR_TEAM_ID`. It archives, signs, notarizes and staples the app, then produces **SnookerPro-Mac.dmg**.
2. Upload SnookerPro-Mac.dmg to your website, next to `snooker.html`.

Users then double-click the DMG, drag Snooker Pro to Applications, and open it normally.

If you skip notarization, macOS blocks the app with a "cannot verify" message. On macOS 15 and later, users would have to go to **System Settings › Privacy & Security › Open Anyway**. Most users won't do that, so always notarize.

Find your Team ID at developer.apple.com under **Account › Membership details**.

## Project layout
| File | Purpose |
|---|---|
| `SnookerProApp.swift` | App entry point; switches between the menu and the game |
| `MenuView.swift` | Start menu, settings and the How to Play screen |
| `GameScene.swift` | Table drawing, touch controls, HUD, turn flow and sounds |
| `PhysicsEngine.swift` | Ball motion, collisions, cushions, pocket jaws, pots and spin |
| `SnookerRules.swift` | Scoring, fouls, re-spotting and the end of the frame |
| `ComputerPlayer.swift` | Computer opponent (ghost-ball aiming, pot selection, ball in hand) |
| `SnookerTable.swift` | Table geometry and the colour spots |
| `Ball.swift` | Ball types, values and vector helpers |
| `build-mac-dmg.sh` | Builds, signs, notarizes and packages the Mac app as a DMG |
