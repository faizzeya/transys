import CoreGraphics

enum BallKind: Int, CaseIterable {
    case cue = 0
    case red = 1
    case yellow = 2
    case green = 3
    case brown = 4
    case blue = 5
    case pink = 6
    case black = 7

    /// Points scored for potting the ball.
    var value: Int { self == .cue ? 0 : rawValue }

    var isColour: Bool { rawValue >= 2 }

    /// Colours in the order they must be potted once the reds are gone.
    static let colourOrder: [BallKind] = [.yellow, .green, .brown, .blue, .pink, .black]

    var name: String {
        switch self {
        case .cue: return "Cue ball"
        case .red: return "Red"
        case .yellow: return "Yellow"
        case .green: return "Green"
        case .brown: return "Brown"
        case .blue: return "Blue"
        case .pink: return "Pink"
        case .black: return "Black"
        }
    }

    /// RGB components used for drawing the ball.
    var rgb: (CGFloat, CGFloat, CGFloat) {
        switch self {
        case .cue:    return (0.97, 0.96, 0.90)
        case .red:    return (0.80, 0.07, 0.09)
        case .yellow: return (0.98, 0.84, 0.10)
        case .green:  return (0.05, 0.50, 0.22)
        case .brown:  return (0.48, 0.27, 0.12)
        case .blue:   return (0.10, 0.30, 0.85)
        case .pink:   return (0.98, 0.52, 0.70)
        case .black:  return (0.06, 0.06, 0.07)
        }
    }
}

/// A ball on the table. Physics works in scene points and seconds.
final class Ball {
    let id: Int
    let kind: BallKind
    var position: CGPoint
    var velocity: CGVector = .zero
    var onTable = true

    init(id: Int, kind: BallKind, position: CGPoint) {
        self.id = id
        self.kind = kind
        self.position = position
    }

    var isMoving: Bool { velocity.dx != 0 || velocity.dy != 0 }
}

// MARK: - Small vector helpers

extension CGPoint {
    static func + (a: CGPoint, b: CGVector) -> CGPoint { CGPoint(x: a.x + b.dx, y: a.y + b.dy) }
    static func - (a: CGPoint, b: CGPoint) -> CGVector { CGVector(dx: a.x - b.x, dy: a.y - b.y) }
    func distance(to p: CGPoint) -> CGFloat { hypot(x - p.x, y - p.y) }
}

extension CGVector {
    static func * (v: CGVector, s: CGFloat) -> CGVector { CGVector(dx: v.dx * s, dy: v.dy * s) }
    static func + (a: CGVector, b: CGVector) -> CGVector { CGVector(dx: a.dx + b.dx, dy: a.dy + b.dy) }
    static func - (a: CGVector, b: CGVector) -> CGVector { CGVector(dx: a.dx - b.dx, dy: a.dy - b.dy) }
    var length: CGFloat { hypot(dx, dy) }
    var normalized: CGVector {
        let l = length
        return l > 0 ? CGVector(dx: dx / l, dy: dy / l) : .zero
    }
    func dot(_ o: CGVector) -> CGFloat { dx * o.dx + dy * o.dy }
}
