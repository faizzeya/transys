import SwiftUI

struct GameSettings {
    var vsComputer: Bool
    var difficulty: ComputerPlayer.Level
    var player1: String
    var player2: String
    var soundOn: Bool
}

struct MenuView: View {
    var onStart: (GameSettings) -> Void

    @AppStorage("vsComputer") private var vsComputer = true
    @AppStorage("difficulty") private var difficulty = 1
    @AppStorage("player1") private var player1 = ""
    @AppStorage("player2") private var player2 = ""
    @AppStorage("soundOn") private var soundOn = true
    @State private var showHelp = false

    private let gold = Color(red: 1, green: 0.82, blue: 0.3)

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.04, green: 0.30, blue: 0.15), Color(red: 0.01, green: 0.12, blue: 0.06)],
                           startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()

            HStack(spacing: 40) {
                // Title side
                VStack(alignment: .leading, spacing: 12) {
                    HStack(spacing: 6) {
                        ForEach([Color.red, .yellow, .green, Color(red: 0.5, green: 0.3, blue: 0.1), .blue, .pink, .black],
                                id: \.self) { c in
                            Circle().fill(c).frame(width: 22, height: 22)
                                .overlay(Circle().stroke(.white.opacity(0.3), lineWidth: 1))
                        }
                    }
                    Text("Snooker Pro")
                        .font(.system(size: 52, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white)
                    Text("Full 15-red snooker with real rules,\ncue spin and a computer opponent.")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundStyle(.white.opacity(0.75))
                    Spacer().frame(height: 8)
                    Button("How to play") { showHelp = true }
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(gold)
                    Spacer()
                    Text("Developed by Transys, Pakistan\nCEO Faiz ul Haque Zeya")
                        .font(.system(size: 12))
                        .foregroundStyle(.white.opacity(0.55))
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                // Options side
                VStack(spacing: 16) {
                    Picker("Mode", selection: $vsComputer) {
                        Text("vs Computer").tag(true)
                        Text("Two Players").tag(false)
                    }
                    .pickerStyle(.segmented)

                    if vsComputer {
                        Picker("Difficulty", selection: $difficulty) {
                            Text("Easy").tag(0)
                            Text("Medium").tag(1)
                            Text("Hard").tag(2)
                        }
                        .pickerStyle(.segmented)
                    }

                    TextField(vsComputer ? "Your name" : "Player 1 name", text: $player1)
                        .textFieldStyle(.roundedBorder)
                        .submitLabel(.done)
                    if !vsComputer {
                        TextField("Player 2 name", text: $player2)
                            .textFieldStyle(.roundedBorder)
                            .submitLabel(.done)
                    }

                    Toggle("Sound", isOn: $soundOn)
                        .foregroundStyle(.white)
                        .tint(gold)

                    Button {
                        onStart(GameSettings(vsComputer: vsComputer,
                                             difficulty: ComputerPlayer.Level(rawValue: difficulty) ?? .medium,
                                             player1: player1.trimmingCharacters(in: .whitespaces),
                                             player2: player2.trimmingCharacters(in: .whitespaces),
                                             soundOn: soundOn))
                    } label: {
                        Text("Start Frame")
                            .font(.system(size: 20, weight: .bold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Color(red: 0.80, green: 0.12, blue: 0.10), in: RoundedRectangle(cornerRadius: 14))
                            .foregroundStyle(.white)
                    }
                }
                .padding(24)
                .frame(width: 360)
                .background(.black.opacity(0.25), in: RoundedRectangle(cornerRadius: 22))
            }
            .padding(.horizontal, 48)
            .padding(.vertical, 28)
        }
        .sheet(isPresented: $showHelp) { HelpView() }
    }
}

struct HelpView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    section("Aim", "Touch or drag anywhere on the table to point the cue. Use ↺ and ↻ for fine adjustments. The dotted line shows where the cue ball goes; the yellow line shows where the object ball will travel.")
                    section("Power and shoot", "Drag the power bar on the right, then tap SHOOT.")
                    section("Spin", "Drag the red dot on the cue ball (top right). Up gives follow, down gives screw (backspin), left and right give side.")
                    section("Ball in hand", "After an in-off, or at the break, drag the cue ball anywhere inside the D before shooting.")
                    section("Rules", "Pot a red (1 point), then any colour: yellow 2, green 3, brown 4, blue 5, pink 6, black 7. Colours are re-spotted while reds remain. When the reds are gone, pot the colours in order from yellow to black. Hitting or potting the wrong ball, missing everything, or potting the cue ball is a foul worth at least 4 points to your opponent.")
                    section("On a Mac", "Click and drag with the mouse or trackpad instead of touching. Keyboard: Space shoots, Left/Right arrows fine-aim (hold Shift for bigger steps), Up/Down arrows change power.")
                    section("Winning", "The frame ends when the black is potted at the end. The higher score wins; a tie is settled on a re-spotted black.")
                }
                .padding(24)
            }
            .navigationTitle("How to play")
            .toolbar { Button("Done") { dismiss() } }
        }
        #if os(macOS)
        .frame(width: 560, height: 560)
        #endif
    }

    private func section(_ title: String, _ body: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.headline)
            Text(body).font(.body).foregroundStyle(.secondary)
        }
    }
}
