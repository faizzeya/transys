import SwiftUI
import SpriteKit

@main
struct SnookerProApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
            #if os(iOS)
                .statusBarHidden(true)
                .persistentSystemOverlays(.hidden)
            #else
                .frame(minWidth: 960, minHeight: 560)
            #endif
                .preferredColorScheme(.dark)
        }
        #if os(macOS)
        .defaultSize(width: 1334, height: 780)
        .commands { CommandGroup(replacing: .newItem) { } }
        #endif
    }
}

struct RootView: View {
    @State private var scene: GameScene?

    var body: some View {
        ZStack {
            Color(red: 0.06, green: 0.08, blue: 0.09).ignoresSafeArea()
            if let scene {
                SpriteView(scene: scene, preferredFramesPerSecond: 60)
                    .ignoresSafeArea()
                    .transition(.opacity)
            } else {
                MenuView { settings in startGame(settings) }
                    .transition(.opacity)
            }
        }
        .animation(.easeInOut(duration: 0.3), value: scene == nil)
    }

    private func startGame(_ settings: GameSettings) {
        let s = GameScene(size: SnookerTable.sceneSize)
        s.scaleMode = .aspectFit
        s.vsComputer = settings.vsComputer
        s.difficulty = settings.difficulty
        s.soundOn = settings.soundOn
        s.playerNames = settings.vsComputer
            ? [settings.player1.isEmpty ? "You" : settings.player1, "Computer"]
            : [settings.player1.isEmpty ? "Player 1" : settings.player1,
               settings.player2.isEmpty ? "Player 2" : settings.player2]
        s.onExit = { scene = nil }
        scene = s
    }
}
