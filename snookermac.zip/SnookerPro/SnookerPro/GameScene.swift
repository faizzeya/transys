import SpriteKit
#if os(iOS)
import UIKit
#else
import AppKit
#endif

/// The playing screen: draws the table, handles touches and runs the frame.
final class GameScene: SKScene {

    // MARK: Configuration (set before presenting)

    var vsComputer = true
    var difficulty: ComputerPlayer.Level = .medium
    var playerNames = ["Player 1", "Player 2"]
    var soundOn = true
    /// Called when the player taps Menu.
    var onExit: (() -> Void)?

    // MARK: Game state

    private enum State { case aiming, rolling, computerTurn, frameOver }

    private let engine = PhysicsEngine()
    private let rules = SnookerRules()
    private var ai = ComputerPlayer()
    private var state: State = .aiming
    private var aimAngle: CGFloat = 0
    private var power: CGFloat = 0.45
    /// x = side spin (-1 left ... 1 right), y = follow (+) / screw (-).
    private var spin = CGPoint.zero
    private var ballInHand = true
    private var lastTime: TimeInterval = 0
    private var lastSoundTime: [PhysicsEngine.ImpactKind: TimeInterval] = [:]
    private var clock: TimeInterval = 0

    private enum TouchMode { case none, aim, power, spin, placeCue }
    private var touchMode: TouchMode = .none

    // MARK: Nodes

    private let tableLayer = SKNode()
    private let ballLayer = SKNode()
    private let hudLayer = SKNode()
    private var ballNodes: [Int: SKNode] = [:]
    private var shownOnTable: [Int: Bool] = [:]
    private let cueStick = SKNode()
    private let aimLine = SKShapeNode()
    private let objectLine = SKShapeNode()
    private let ghostBall = SKShapeNode(circleOfRadius: SnookerTable.ballRadius)
    private let dHighlight = SKShapeNode()

    private var nameLabels: [SKLabelNode] = []
    private var scoreLabels: [SKLabelNode] = []
    private var turnMarkers: [SKShapeNode] = []
    private let ballOnLabel = SKLabelNode(fontNamed: "AvenirNext-DemiBold")
    private let ballOnDot = SKShapeNode(circleOfRadius: 8)
    private let statusLabel = SKLabelNode(fontNamed: "AvenirNext-Medium")
    private let breakLabel = SKLabelNode(fontNamed: "AvenirNext-Medium")
    private let powerFill = SKShapeNode()
    private let powerLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
    private let spinDot = SKShapeNode(circleOfRadius: 6)
    private var overlay: SKNode?

    // HUD geometry
    private let powerBar = CGRect(x: 1254, y: 150, width: 30, height: 370)
    private let shootCenter = CGPoint(x: 1269, y: 88)
    private let spinCenter = CGPoint(x: 1269, y: 684)
    private let spinRadius: CGFloat = 36
    private let rotateLeftCenter = CGPoint(x: 1240, y: 578)
    private let rotateRightCenter = CGPoint(x: 1298, y: 578)
    private let menuCenter = CGPoint(x: 58, y: 712)

    private let font = "AvenirNext-DemiBold"
    private let clothColor = SKColor(red: 0.05, green: 0.42, blue: 0.20, alpha: 1)

    // MARK: - Setup

    override func didMove(to view: SKView) {
        backgroundColor = SKColor(red: 0.06, green: 0.08, blue: 0.09, alpha: 1)
        ai.level = difficulty
        addChild(tableLayer)
        addChild(ballLayer)
        addChild(hudLayer)
        buildTable()
        buildBalls()
        buildAimNodes()
        buildHUD()
        engine.onImpact = { [weak self] kind, strength in self?.playImpact(kind, strength: strength) }
        #if os(macOS)
        // Let the scene receive keyboard shortcuts.
        DispatchQueue.main.async { view.window?.makeFirstResponder(view) }
        #endif
        startFrame()
    }

    private func startFrame() {
        overlay?.removeFromParent()
        overlay = nil
        engine.reset()
        rules.reset()
        rules.current = Int.random(in: 0...1)
        for b in engine.balls {
            shownOnTable[b.id] = true
            ballNodes[b.id]?.removeAllActions()
            ballNodes[b.id]?.alpha = 1
            ballNodes[b.id]?.setScale(1)
            ballNodes[b.id]?.isHidden = false
        }
        ballInHand = true
        syncBalls()
        refreshHUD()
        setStatus("\(playerNames[rules.current]) to break — place the cue ball in the D")
        beginTurn()
    }

    // MARK: - Table drawing

    private func buildTable() {
        let play = SnookerTable.playRect
        let cw = SnookerTable.cushionWidth

        // Wooden frame
        let frameRect = play.insetBy(dx: -(cw + 22), dy: -(cw + 22))
        let wood = SKShapeNode(rect: frameRect, cornerRadius: 22)
        wood.fillColor = SKColor(red: 0.36, green: 0.20, blue: 0.09, alpha: 1)
        wood.strokeColor = SKColor(red: 0.20, green: 0.10, blue: 0.04, alpha: 1)
        wood.lineWidth = 3
        tableLayer.addChild(wood)

        let woodShine = SKShapeNode(rect: frameRect.insetBy(dx: 5, dy: 5), cornerRadius: 18)
        woodShine.fillColor = .clear
        woodShine.strokeColor = SKColor(red: 0.55, green: 0.33, blue: 0.16, alpha: 0.6)
        woodShine.lineWidth = 2
        tableLayer.addChild(woodShine)

        // Diamond sights on the wood
        for i in 1..<8 where i != 4 {
            let x = play.minX + play.width * CGFloat(i) / 8
            for y in [frameRect.minY + 11, frameRect.maxY - 11] { addSight(at: CGPoint(x: x, y: y)) }
        }
        for i in 1..<4 {
            let y = play.minY + play.height * CGFloat(i) / 4
            for x in [frameRect.minX + 11, frameRect.maxX - 11] { addSight(at: CGPoint(x: x, y: y)) }
        }

        // Cushions
        let cushion = SKShapeNode(rect: play.insetBy(dx: -cw, dy: -cw), cornerRadius: 6)
        cushion.fillColor = SKColor(red: 0.03, green: 0.32, blue: 0.15, alpha: 1)
        cushion.strokeColor = .clear
        tableLayer.addChild(cushion)

        // Cloth
        let cloth = SKShapeNode(rect: play)
        cloth.fillColor = clothColor
        cloth.strokeColor = SKColor(red: 0.02, green: 0.25, blue: 0.11, alpha: 1)
        cloth.lineWidth = 2
        tableLayer.addChild(cloth)

        // Soft light from the lamps above the table
        for f in [0.25, 0.5, 0.75] as [CGFloat] {
            let glow = SKShapeNode(ellipseOf: CGSize(width: play.width * 0.42, height: play.height * 0.8))
            glow.position = CGPoint(x: play.minX + play.width * f, y: play.midY)
            glow.fillColor = SKColor(white: 1, alpha: 0.035)
            glow.strokeColor = .clear
            tableLayer.addChild(glow)
        }

        // Baulk line and the D
        let markings = SKShapeNode()
        let path = CGMutablePath()
        path.move(to: CGPoint(x: SnookerTable.baulkX, y: play.minY))
        path.addLine(to: CGPoint(x: SnookerTable.baulkX, y: play.maxY))
        let brown = SnookerTable.spot(for: .brown)
        path.move(to: CGPoint(x: brown.x, y: brown.y + SnookerTable.dRadius))
        path.addArc(center: brown, radius: SnookerTable.dRadius,
                    startAngle: .pi / 2, endAngle: 3 * .pi / 2, clockwise: false)
        markings.path = path
        markings.strokeColor = SKColor(white: 1, alpha: 0.55)
        markings.lineWidth = 1.5
        tableLayer.addChild(markings)

        // Highlight shown while the cue ball is in hand
        let dPath = CGMutablePath()
        dPath.move(to: CGPoint(x: brown.x, y: brown.y + SnookerTable.dRadius))
        dPath.addArc(center: brown, radius: SnookerTable.dRadius,
                     startAngle: .pi / 2, endAngle: 3 * .pi / 2, clockwise: false)
        dPath.closeSubpath()
        dHighlight.path = dPath
        dHighlight.fillColor = SKColor(white: 1, alpha: 0.08)
        dHighlight.strokeColor = SKColor(red: 1, green: 0.85, blue: 0.3, alpha: 0.8)
        dHighlight.lineWidth = 2
        dHighlight.isHidden = true
        tableLayer.addChild(dHighlight)

        // Spots
        for kind in BallKind.colourOrder {
            let spot = SKShapeNode(circleOfRadius: 1.8)
            spot.position = SnookerTable.spot(for: kind)
            spot.fillColor = SKColor(white: 1, alpha: 0.6)
            spot.strokeColor = .clear
            tableLayer.addChild(spot)
        }

        // Pockets
        for (i, p) in SnookerTable.pockets.enumerated() {
            let rim = SKShapeNode(circleOfRadius: i < 4 ? 19 : 17)
            rim.position = p
            rim.fillColor = SKColor(red: 0.75, green: 0.62, blue: 0.30, alpha: 1)
            rim.strokeColor = .clear
            tableLayer.addChild(rim)
            let hole = SKShapeNode(circleOfRadius: i < 4 ? 16 : 14.5)
            hole.position = p
            hole.fillColor = SKColor(white: 0.02, alpha: 1)
            hole.strokeColor = .clear
            tableLayer.addChild(hole)
        }
    }

    private func addSight(at p: CGPoint) {
        let d = SKShapeNode(circleOfRadius: 2.5)
        d.position = p
        d.fillColor = SKColor(red: 0.95, green: 0.88, blue: 0.70, alpha: 1)
        d.strokeColor = .clear
        tableLayer.addChild(d)
    }

    private func buildBalls() {
        let r = SnookerTable.ballRadius
        for b in engine.balls {
            let (red, green, blue) = b.kind.rgb
            let node = SKShapeNode(circleOfRadius: r)
            node.fillColor = SKColor(red: red, green: green, blue: blue, alpha: 1)
            node.strokeColor = SKColor(red: red * 0.5, green: green * 0.5, blue: blue * 0.5, alpha: 1)
            node.lineWidth = 1

            let shadow = SKShapeNode(circleOfRadius: r)
            shadow.fillColor = SKColor(white: 0, alpha: 0.35)
            shadow.strokeColor = .clear
            shadow.position = CGPoint(x: 2.5, y: -2.5)
            shadow.zPosition = -1
            node.addChild(shadow)

            let shine = SKShapeNode(circleOfRadius: r * 0.32)
            shine.fillColor = SKColor(white: 1, alpha: 0.55)
            shine.strokeColor = .clear
            shine.position = CGPoint(x: -r * 0.35, y: r * 0.38)
            node.addChild(shine)

            ballLayer.addChild(node)
            ballNodes[b.id] = node
            shownOnTable[b.id] = true
        }
    }

    private func buildAimNodes() {
        aimLine.strokeColor = SKColor(white: 1, alpha: 0.75)
        aimLine.lineWidth = 1.5
        aimLine.zPosition = 5
        objectLine.strokeColor = SKColor(red: 1, green: 0.9, blue: 0.4, alpha: 0.85)
        objectLine.lineWidth = 1.5
        objectLine.zPosition = 5
        ghostBall.strokeColor = SKColor(white: 1, alpha: 0.8)
        ghostBall.fillColor = SKColor(white: 1, alpha: 0.12)
        ghostBall.lineWidth = 1.2
        ghostBall.zPosition = 5
        ballLayer.addChild(aimLine)
        ballLayer.addChild(objectLine)
        ballLayer.addChild(ghostBall)

        // Cue stick, drawn pointing along +x with the tip at x = 0.
        let length: CGFloat = 420
        func part(from x0: CGFloat, to x1: CGFloat, w0: CGFloat, w1: CGFloat, color: SKColor) -> SKShapeNode {
            let p = CGMutablePath()
            p.move(to: CGPoint(x: x0, y: -w0 / 2))
            p.addLine(to: CGPoint(x: x1, y: -w1 / 2))
            p.addLine(to: CGPoint(x: x1, y: w1 / 2))
            p.addLine(to: CGPoint(x: x0, y: w0 / 2))
            p.closeSubpath()
            let n = SKShapeNode(path: p)
            n.fillColor = color
            n.strokeColor = .clear
            return n
        }
        let stickShadow = part(from: -length, to: 0, w0: 13, w1: 6, color: SKColor(white: 0, alpha: 0.3))
        stickShadow.position = CGPoint(x: 4, y: -5)
        cueStick.addChild(stickShadow)
        cueStick.addChild(part(from: -length, to: -length * 0.42, w0: 13, w1: 10,
                               color: SKColor(red: 0.18, green: 0.09, blue: 0.04, alpha: 1)))
        cueStick.addChild(part(from: -length * 0.42, to: -8, w0: 10, w1: 6.5,
                               color: SKColor(red: 0.86, green: 0.70, blue: 0.45, alpha: 1)))
        cueStick.addChild(part(from: -8, to: -3, w0: 6.5, w1: 6,
                               color: SKColor(red: 0.96, green: 0.94, blue: 0.88, alpha: 1)))
        cueStick.addChild(part(from: -3, to: 0, w0: 6, w1: 6,
                               color: SKColor(red: 0.20, green: 0.45, blue: 0.85, alpha: 1)))
        cueStick.zPosition = 10
        ballLayer.addChild(cueStick)
    }

    // MARK: - HUD

    private func label(_ text: String, size: CGFloat, at p: CGPoint, font name: String? = nil,
                       color: SKColor = .white, align: SKLabelHorizontalAlignmentMode = .center) -> SKLabelNode {
        let l = SKLabelNode(fontNamed: name ?? font)
        l.text = text
        l.fontSize = size
        l.fontColor = color
        l.position = p
        l.horizontalAlignmentMode = align
        l.verticalAlignmentMode = .center
        hudLayer.addChild(l)
        return l
    }

    private func buildHUD() {
        // Player panels
        for i in 0..<2 {
            let x: CGFloat = i == 0 ? 330 : 950
            let panel = SKShapeNode(rect: CGRect(x: x - 170, y: 648, width: 340, height: 92), cornerRadius: 14)
            panel.fillColor = SKColor(white: 1, alpha: 0.06)
            panel.strokeColor = SKColor(white: 1, alpha: 0.12)
            hudLayer.addChild(panel)

            let marker = SKShapeNode(rect: CGRect(x: x - 170, y: 648, width: 340, height: 92), cornerRadius: 14)
            marker.fillColor = .clear
            marker.strokeColor = SKColor(red: 1, green: 0.82, blue: 0.25, alpha: 1)
            marker.lineWidth = 3
            hudLayer.addChild(marker)
            turnMarkers.append(marker)

            nameLabels.append(label(playerNames[i], size: 22, at: CGPoint(x: x - 150, y: 712), align: .left))
            scoreLabels.append(label("0", size: 44, at: CGPoint(x: x + 150, y: 694),
                                     font: "AvenirNext-Heavy", align: .right))
        }

        // Centre: ball on, break, status
        ballOnDot.position = CGPoint(x: 588, y: 718)
        ballOnDot.strokeColor = SKColor(white: 1, alpha: 0.6)
        hudLayer.addChild(ballOnDot)
        ballOnLabel.fontSize = 20
        ballOnLabel.horizontalAlignmentMode = .left
        ballOnLabel.verticalAlignmentMode = .center
        ballOnLabel.position = CGPoint(x: 604, y: 718)
        hudLayer.addChild(ballOnLabel)

        breakLabel.fontSize = 16
        breakLabel.fontColor = SKColor(white: 0.8, alpha: 1)
        breakLabel.verticalAlignmentMode = .center
        breakLabel.position = CGPoint(x: 640, y: 690)
        hudLayer.addChild(breakLabel)

        statusLabel.fontSize = 15
        statusLabel.fontColor = SKColor(red: 1, green: 0.88, blue: 0.5, alpha: 1)
        statusLabel.verticalAlignmentMode = .center
        statusLabel.position = CGPoint(x: 640, y: 662)
        hudLayer.addChild(statusLabel)

        // Menu button
        let menu = SKShapeNode(rect: CGRect(x: menuCenter.x - 44, y: menuCenter.y - 20, width: 88, height: 40), cornerRadius: 10)
        menu.fillColor = SKColor(white: 1, alpha: 0.1)
        menu.strokeColor = SKColor(white: 1, alpha: 0.25)
        hudLayer.addChild(menu)
        _ = label("Menu", size: 17, at: menuCenter)

        // Spin control
        let cueFace = SKShapeNode(circleOfRadius: spinRadius)
        cueFace.position = spinCenter
        cueFace.fillColor = SKColor(red: 0.97, green: 0.96, blue: 0.90, alpha: 1)
        cueFace.strokeColor = SKColor(white: 0.6, alpha: 1)
        cueFace.lineWidth = 2
        hudLayer.addChild(cueFace)
        let cross = SKShapeNode()
        let cp = CGMutablePath()
        cp.move(to: CGPoint(x: spinCenter.x - spinRadius, y: spinCenter.y))
        cp.addLine(to: CGPoint(x: spinCenter.x + spinRadius, y: spinCenter.y))
        cp.move(to: CGPoint(x: spinCenter.x, y: spinCenter.y - spinRadius))
        cp.addLine(to: CGPoint(x: spinCenter.x, y: spinCenter.y + spinRadius))
        cross.path = cp
        cross.strokeColor = SKColor(white: 0.7, alpha: 1)
        hudLayer.addChild(cross)
        spinDot.fillColor = SKColor(red: 0.85, green: 0.1, blue: 0.1, alpha: 1)
        spinDot.strokeColor = .clear
        hudLayer.addChild(spinDot)
        _ = label("SPIN", size: 11, at: CGPoint(x: spinCenter.x, y: spinCenter.y - spinRadius - 9),
                  color: SKColor(white: 0.75, alpha: 1))

        // Fine aim buttons
        for (c, t) in [(rotateLeftCenter, "↺"), (rotateRightCenter, "↻")] {
            let b = SKShapeNode(circleOfRadius: 22)
            b.position = c
            b.fillColor = SKColor(white: 1, alpha: 0.1)
            b.strokeColor = SKColor(white: 1, alpha: 0.3)
            hudLayer.addChild(b)
            _ = label(t, size: 24, at: c, font: "HelveticaNeue-Bold")
        }
        _ = label("FINE AIM", size: 10, at: CGPoint(x: 1269, y: 548), color: SKColor(white: 0.75, alpha: 1))

        // Power bar
        let bar = SKShapeNode(rect: powerBar, cornerRadius: 8)
        bar.fillColor = SKColor(white: 1, alpha: 0.08)
        bar.strokeColor = SKColor(white: 1, alpha: 0.3)
        hudLayer.addChild(bar)
        powerFill.strokeColor = .clear
        hudLayer.addChild(powerFill)
        powerLabel.fontSize = 14
        powerLabel.verticalAlignmentMode = .center
        powerLabel.position = CGPoint(x: powerBar.midX, y: powerBar.minY - 16)
        hudLayer.addChild(powerLabel)
        _ = label("POWER", size: 10, at: CGPoint(x: powerBar.midX, y: powerBar.maxY + 12),
                  color: SKColor(white: 0.75, alpha: 1))

        // Shoot button
        let shoot = SKShapeNode(circleOfRadius: 38)
        shoot.position = shootCenter
        shoot.fillColor = SKColor(red: 0.80, green: 0.12, blue: 0.10, alpha: 1)
        shoot.strokeColor = SKColor(white: 1, alpha: 0.7)
        shoot.lineWidth = 2
        hudLayer.addChild(shoot)
        _ = label("SHOOT", size: 15, at: shootCenter, font: "AvenirNext-Heavy")

        updatePowerBar()
        updateSpinDot()
    }

    private func refreshHUD() {
        for i in 0..<2 {
            scoreLabels[i].text = "\(rules.scores[i])"
            turnMarkers[i].isHidden = rules.current != i || rules.frameOver
        }
        let on = rules.ballOn
        ballOnLabel.text = "Ball on: \(on.description)"
        switch on {
        case .red: ballOnDot.fillColor = colour(.red)
        case .anyColour: ballOnDot.fillColor = SKColor(red: 0.6, green: 0.3, blue: 0.9, alpha: 1)
        case .clearance(let i): ballOnDot.fillColor = colour(BallKind.colourOrder[i])
        }
        let reds = engine.balls.filter { $0.onTable && $0.kind == .red }.count
        let remaining = rules.pointsRemaining(redsOnTable: reds, physics: engine)
        breakLabel.text = "Break \(rules.currentBreak)   ·   Reds \(reds)   ·   Remaining \(remaining)"
    }

    private func colour(_ k: BallKind) -> SKColor {
        let (r, g, b) = k.rgb
        return SKColor(red: r, green: g, blue: b, alpha: 1)
    }

    private func setStatus(_ text: String) { statusLabel.text = text }

    private func updatePowerBar() {
        let h = max(12, (powerBar.height - 6) * power)
        powerFill.path = CGPath(roundedRect: CGRect(x: powerBar.minX + 3, y: powerBar.minY + 3,
                                                    width: powerBar.width - 6, height: h),
                                cornerWidth: 5, cornerHeight: 5, transform: nil)
        powerFill.fillColor = SKColor(red: min(1, 0.3 + power), green: max(0.2, 1 - power * 0.9), blue: 0.15, alpha: 1)
        powerLabel.text = "\(Int((power * 100).rounded()))%"
    }

    private func updateSpinDot() {
        spinDot.position = CGPoint(x: spinCenter.x + spin.x * (spinRadius - 8),
                                   y: spinCenter.y + spin.y * (spinRadius - 8))
    }

    // MARK: - Turn flow

    private var isHumanTurn: Bool { !(vsComputer && rules.current == 1) }

    private func beginTurn() {
        if ballInHand && !inD(engine.cueBall.position) {
            let brown = SnookerTable.spot(for: .brown)
            let options = [SnookerTable.defaultCuePosition, brown + CGVector(dx: -40, dy: 0),
                           brown + CGVector(dx: -30, dy: 40), brown + CGVector(dx: -30, dy: -40)]
            engine.cueBall.position = options.first { engine.isFree($0, ignoring: engine.cueBall) } ?? options[0]
            syncBalls()
        }
        refreshHUD()
        aimAtNearestBallOn()
        dHighlight.isHidden = !ballInHand
        if isHumanTurn {
            state = .aiming
            showAim(true)
            if ballInHand && !rules.frameOver {
                setStatus("\(playerNames[rules.current]): ball in hand — drag the cue ball in the D")
            }
        } else {
            state = .computerTurn
            showAim(false)
            run(.wait(forDuration: 0.8)) { [weak self] in self?.playComputerShot() }
        }
    }

    private func playComputerShot() {
        guard state == .computerTurn else { return }
        let plan = ai.plan(physics: engine, ballOn: rules.ballOn, ballInHand: ballInHand)
        if let p = plan.cuePosition {
            engine.cueBall.position = p
            syncBalls()
        }
        aimAngle = atan2(plan.direction.dy, plan.direction.dx)
        power = plan.power
        spin = CGPoint(x: 0, y: plan.spin)
        updatePowerBar()
        updateSpinDot()
        showAim(true)
        setStatus("\(playerNames[1]) is lining up a shot…")
        // Draw the cue back, then strike.
        run(.wait(forDuration: 0.9)) { [weak self] in self?.shoot() }
    }

    private func shoot() {
        guard state == .aiming || state == .computerTurn else { return }
        engine.cueSpin = spin.y
        engine.cueSide = spin.x
        engine.shoot(direction: CGVector(dx: cos(aimAngle), dy: sin(aimAngle)), power: power)
        ballInHand = false
        dHighlight.isHidden = true
        state = .rolling
        showAim(false)
        playSound("hit", minGap: 0)
        #if os(iOS)
        if isHumanTurn { UIImpactFeedbackGenerator(style: .medium).impactOccurred(intensity: 0.4 + power * 0.6) }
        #endif
        setStatus("")
    }

    private func shotFinished() {
        let outcome = rules.evaluate(engine.events, physics: engine)
        ballInHand = outcome.cueBallInHand
        syncBalls()
        refreshHUD()
        if outcome.frameOver {
            state = .frameOver
            refreshHUD()
            showFrameOver()
            return
        }
        if outcome.foul {
            setStatus(outcome.message)
            #if os(iOS)
            if isHumanTurn { UINotificationFeedbackGenerator().notificationOccurred(.warning) }
            #endif
        } else if outcome.turnContinues {
            setStatus("\(outcome.message)   ·   break \(rules.currentBreak)")
        } else {
            setStatus("\(playerNames[rules.current]) to play")
        }
        beginTurn()
    }

    // MARK: - Aiming

    private func showAim(_ visible: Bool) {
        cueStick.isHidden = !visible
        aimLine.isHidden = !visible
        objectLine.isHidden = !visible
        ghostBall.isHidden = !visible
        if visible { updateAimGraphics() }
    }

    private func aimAtNearestBallOn() {
        let cue = engine.cueBall.position
        let targets = engine.balls.filter { $0.onTable && $0.kind != .cue && rules.ballOn.accepts($0.kind) }
        if let t = targets.min(by: { $0.position.distance(to: cue) < $1.position.distance(to: cue) }) {
            let d = t.position - cue
            aimAngle = atan2(d.dy, d.dx)
        }
    }

    /// Draws the cue, the aiming line, the ghost ball and the object ball's path.
    private func updateAimGraphics() {
        let cue = engine.cueBall.position
        let dir = CGVector(dx: cos(aimAngle), dy: sin(aimAngle))
        let r = SnookerTable.ballRadius
        cueStick.position = cue
        cueStick.zRotation = aimAngle
        let pull = r + 4 + power * 46
        for child in cueStick.children { child.position.x = -pull + (child === cueStick.children.first ? 4 : 0) }

        // First ball the cue ball would hit.
        var hitT = CGFloat.greatestFiniteMagnitude
        var hitBall: Ball?
        for b in engine.balls where b.onTable && b.kind != .cue {
            let m = cue - b.position
            let bq = m.dot(dir)
            let c = m.dot(m) - 4 * r * r
            let disc = bq * bq - c
            guard disc >= 0 else { continue }
            let t = -bq - sqrt(disc)
            if t > 0 && t < hitT { hitT = t; hitBall = b }
        }
        // Distance to the cushion line.
        let play = SnookerTable.playRect.insetBy(dx: r, dy: r)
        var wallT = CGFloat.greatestFiniteMagnitude
        if dir.dx > 0 { wallT = min(wallT, (play.maxX - cue.x) / dir.dx) }
        if dir.dx < 0 { wallT = min(wallT, (play.minX - cue.x) / dir.dx) }
        if dir.dy > 0 { wallT = min(wallT, (play.maxY - cue.y) / dir.dy) }
        if dir.dy < 0 { wallT = min(wallT, (play.minY - cue.y) / dir.dy) }

        let t = min(hitT, wallT)
        let end = cue + dir * t
        let line = CGMutablePath()
        line.move(to: cue + dir * r)
        line.addLine(to: end)
        aimLine.path = line.copy(dashingWithPhase: 0, lengths: [7, 5])
        ghostBall.position = end

        if let b = hitBall, hitT <= wallT {
            let n = (b.position - end).normalized
            let op = CGMutablePath()
            op.move(to: b.position)
            op.addLine(to: b.position + n * 90)
            objectLine.path = op
            objectLine.isHidden = cueStick.isHidden
            let legal = rules.ballOn.accepts(b.kind)
            ghostBall.strokeColor = legal ? SKColor(white: 1, alpha: 0.85) : SKColor(red: 1, green: 0.3, blue: 0.3, alpha: 0.9)
        } else {
            objectLine.isHidden = true
            ghostBall.strokeColor = SKColor(white: 1, alpha: 0.5)
        }
    }

    // MARK: - Input (touch on iPhone/iPad, mouse and keyboard on Mac)

    private func pressBegan(at p: CGPoint) {
        if let overlay = overlay {
            handleOverlayTap(p, overlay: overlay)
            return
        }
        if p.distance(to: menuCenter) < 46 && abs(p.y - menuCenter.y) < 26 {
            onExit?()
            return
        }
        guard state == .aiming else { return }

        if p.distance(to: shootCenter) < 44 {
            shoot()
            touchMode = .none
        } else if p.distance(to: spinCenter) < spinRadius + 10 {
            touchMode = .spin
            setSpin(p)
        } else if powerBar.insetBy(dx: -24, dy: -14).contains(p) {
            touchMode = .power
            setPower(p)
        } else if p.distance(to: rotateLeftCenter) < 26 {
            fineAim(+1)
        } else if p.distance(to: rotateRightCenter) < 26 {
            fineAim(-1)
        } else if ballInHand && (inD(p) || p.distance(to: engine.cueBall.position) < 30) {
            touchMode = .placeCue
            placeCue(p)
        } else if p.x < powerBar.minX - 30 && p.y < 640 {
            touchMode = .aim
            aim(at: p)
        }
    }

    private func pressMoved(to p: CGPoint) {
        guard state == .aiming else { return }
        switch touchMode {
        case .aim: aim(at: p)
        case .power: setPower(p)
        case .spin: setSpin(p)
        case .placeCue: placeCue(p)
        case .none: break
        }
    }

    private func pressEnded() { touchMode = .none }

    private func fineAim(_ direction: CGFloat) {
        aimAngle += 0.0025 * direction
        updateAimGraphics()
    }

    private func nudgePower(_ delta: CGFloat) {
        power = max(0.02, min(1, power + delta))
        updatePowerBar()
        updateAimGraphics()
    }

#if os(iOS)
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let p = touches.first?.location(in: self) else { return }
        pressBegan(at: p)
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let p = touches.first?.location(in: self) else { return }
        pressMoved(to: p)
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) { pressEnded() }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) { pressEnded() }
#else
    override func mouseDown(with event: NSEvent) { pressBegan(at: event.location(in: self)) }
    override func mouseDragged(with event: NSEvent) { pressMoved(to: event.location(in: self)) }
    override func mouseUp(with event: NSEvent) { pressEnded() }

    /// Keyboard: Space shoots, Left/Right fine-aim (hold Shift for bigger steps),
    /// Up/Down change power.
    override func keyDown(with event: NSEvent) {
        guard state == .aiming, overlay == nil else { return }
        let step: CGFloat = event.modifierFlags.contains(.shift) ? 8 : 1
        switch event.keyCode {
        case 49: shoot()                       // Space
        case 123: fineAim(+step)               // Left arrow
        case 124: fineAim(-step)               // Right arrow
        case 126: nudgePower(0.02)             // Up arrow
        case 125: nudgePower(-0.02)            // Down arrow
        default: super.keyDown(with: event)
        }
    }
#endif

    private func aim(at p: CGPoint) {
        let d = p - engine.cueBall.position
        guard d.length > 2 else { return }
        aimAngle = atan2(d.dy, d.dx)
        updateAimGraphics()
    }

    private func setPower(_ p: CGPoint) {
        power = max(0.02, min(1, (p.y - powerBar.minY) / powerBar.height))
        updatePowerBar()
        updateAimGraphics()
    }

    private func setSpin(_ p: CGPoint) {
        var v = CGVector(dx: (p.x - spinCenter.x) / (spinRadius - 8), dy: (p.y - spinCenter.y) / (spinRadius - 8))
        if v.length > 1 { v = v.normalized }
        spin = CGPoint(x: v.dx, y: v.dy)
        updateSpinDot()
    }

    private func inD(_ p: CGPoint) -> Bool {
        let brown = SnookerTable.spot(for: .brown)
        return p.x <= SnookerTable.baulkX && p.distance(to: brown) <= SnookerTable.dRadius
    }

    private func placeCue(_ p: CGPoint) {
        // Clamp the point into the D.
        let brown = SnookerTable.spot(for: .brown)
        var q = CGPoint(x: min(p.x, SnookerTable.baulkX), y: p.y)
        let d = q - brown
        let maxR = SnookerTable.dRadius - 1
        if d.length > maxR { q = brown + d.normalized * maxR }
        guard engine.isFree(q, ignoring: engine.cueBall) else { return }
        engine.cueBall.position = q
        syncBalls()
        updateAimGraphics()
    }

    // MARK: - Frame over

    private func showFrameOver() {
        showAim(false)
        let node = SKNode()
        node.zPosition = 100
        let dim = SKShapeNode(rect: CGRect(origin: .zero, size: size))
        dim.fillColor = SKColor(white: 0, alpha: 0.6)
        dim.strokeColor = .clear
        node.addChild(dim)

        let panel = SKShapeNode(rect: CGRect(x: 367, y: 215, width: 600, height: 320), cornerRadius: 24)
        panel.fillColor = SKColor(red: 0.07, green: 0.20, blue: 0.12, alpha: 0.97)
        panel.strokeColor = SKColor(red: 1, green: 0.82, blue: 0.25, alpha: 1)
        panel.lineWidth = 3
        node.addChild(panel)

        let w = rules.winner ?? 0
        func add(_ text: String, _ size: CGFloat, _ y: CGFloat, _ font: String = "AvenirNext-DemiBold",
                 _ color: SKColor = .white) {
            let l = SKLabelNode(fontNamed: font)
            l.text = text
            l.fontSize = size
            l.fontColor = color
            l.verticalAlignmentMode = .center
            l.position = CGPoint(x: 667, y: y)
            node.addChild(l)
        }
        add("\(playerNames[w]) wins the frame!", 36, 480, "AvenirNext-Heavy", SKColor(red: 1, green: 0.85, blue: 0.35, alpha: 1))
        add("\(playerNames[0])  \(rules.scores[0])  –  \(rules.scores[1])  \(playerNames[1])", 28, 420)
        add("Highest breaks:  \(rules.highestBreak[0])  /  \(rules.highestBreak[1])", 18, 375, "AvenirNext-Medium")

        for (title, x, name) in [("Play Again", 557.0, "again"), ("Menu", 777.0, "menu")] as [(String, CGFloat, String)] {
            let b = SKShapeNode(rect: CGRect(x: x - 90, y: 255, width: 180, height: 56), cornerRadius: 14)
            b.fillColor = name == "again" ? SKColor(red: 0.80, green: 0.12, blue: 0.10, alpha: 1) : SKColor(white: 1, alpha: 0.12)
            b.strokeColor = SKColor(white: 1, alpha: 0.5)
            b.name = name
            node.addChild(b)
            let l = SKLabelNode(fontNamed: "AvenirNext-Bold")
            l.text = title
            l.fontSize = 20
            l.verticalAlignmentMode = .center
            l.position = CGPoint(x: x, y: 283)
            node.addChild(l)
        }
        addChild(node)
        overlay = node
        playSound("pocket", minGap: 0)
    }

    private func handleOverlayTap(_ p: CGPoint, overlay: SKNode) {
        guard p.y > 250 && p.y < 316 else { return }
        if abs(p.x - 557) < 95 { startFrame() }
        else if abs(p.x - 777) < 95 { onExit?() }
    }

    // MARK: - Loop

    override func update(_ currentTime: TimeInterval) {
        let dt = lastTime == 0 ? 1.0 / 60 : min(1.0 / 30, currentTime - lastTime)
        lastTime = currentTime
        clock = currentTime
        guard state == .rolling else { return }
        engine.step(CGFloat(dt))
        syncBalls()
        if !engine.isMoving { shotFinished() }
    }

    /// Moves the ball sprites to match the physics, animating pots.
    private func syncBalls() {
        for b in engine.balls {
            guard let node = ballNodes[b.id] else { continue }
            let wasOn = shownOnTable[b.id] ?? true
            if b.onTable {
                if !wasOn {
                    node.removeAllActions()
                    node.isHidden = false
                    node.alpha = 0
                    node.setScale(1)
                    node.run(.fadeIn(withDuration: 0.25))
                }
                node.position = b.position
            } else if wasOn {
                let pocket = SnookerTable.pockets.min { $0.distance(to: b.position) < $1.distance(to: b.position) } ?? b.position
                node.run(.sequence([
                    .group([.move(to: pocket, duration: 0.12), .scale(to: 0.5, duration: 0.18), .fadeOut(withDuration: 0.18)]),
                    .hide()
                ]))
            }
            shownOnTable[b.id] = b.onTable
        }
    }

    // MARK: - Sound

    private func playImpact(_ kind: PhysicsEngine.ImpactKind, strength: CGFloat) {
        switch kind {
        case .ball: if strength > 25 { playSound("hit", minGap: 0.04, kind: kind) }
        case .cushion: if strength > 60 { playSound("cushion", minGap: 0.06, kind: kind) }
        case .pocket: playSound("pocket", minGap: 0.05, kind: kind)
        }
    }

    private func playSound(_ name: String, minGap: TimeInterval, kind: PhysicsEngine.ImpactKind? = nil) {
        guard soundOn else { return }
        if let k = kind {
            if let last = lastSoundTime[k], clock - last < minGap { return }
            lastSoundTime[k] = clock
        }
        run(.playSoundFileNamed("\(name).wav", waitForCompletion: false))
    }
}
