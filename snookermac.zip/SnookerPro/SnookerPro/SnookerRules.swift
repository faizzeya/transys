import Foundation

/// Which ball(s) the player striking must hit first.
enum BallOn: Equatable {
    case red
    case anyColour
    /// During the final clearance: colourOrder[index].
    case clearance(Int)

    var description: String {
        switch self {
        case .red: return "Red"
        case .anyColour: return "Colour"
        case .clearance(let i): return BallKind.colourOrder[i].name
        }
    }

    func accepts(_ kind: BallKind) -> Bool {
        switch self {
        case .red: return kind == .red
        case .anyColour: return kind.isColour
        case .clearance(let i): return kind == BallKind.colourOrder[i]
        }
    }
}

struct ShotOutcome {
    var points = 0
    var foul = false
    var foulPoints = 0
    var message = ""
    var turnContinues = false
    var cueBallInHand = false
    var frameOver = false
}

/// The rules of snooker (fouls, scoring, re-spotting, the final clearance).
/// Free balls and the "miss" rule are not enforced, as in most casual play.
final class SnookerRules {
    var scores = [0, 0]
    var current = 0
    var ballOn: BallOn = .red
    var currentBreak = 0
    var highestBreak = [0, 0]
    private(set) var frameOver = false

    func reset() {
        scores = [0, 0]
        current = 0
        ballOn = .red
        currentBreak = 0
        highestBreak = [0, 0]
        frameOver = false
    }

    var opponent: Int { 1 - current }

    /// Points still available to be scored on the table.
    func pointsRemaining(redsOnTable: Int, physics: PhysicsEngine) -> Int {
        let coloursOnTable = physics.balls.filter { $0.onTable && $0.kind.isColour }
        let colourTotal = coloursOnTable.reduce(0) { $0 + $1.kind.value }
        var extra = redsOnTable * 8 // each red plus a black
        if ballOn == .anyColour { extra += 7 }
        return colourTotal + extra
    }

    /// Applies the result of a shot. The physics balls have stopped moving.
    func evaluate(_ events: ShotEvents, physics: PhysicsEngine) -> ShotOutcome {
        var out = ShotOutcome()
        let redsLeft = physics.balls.filter { $0.onTable && $0.kind == .red }.count
        let potted = events.potted
        let pottedKinds = potted.map { $0.kind }
        let wasOn = ballOn

        // Value of the ball on, for the foul penalty.
        var onValue: Int
        switch wasOn {
        case .red: onValue = 1
        case .anyColour: onValue = events.firstContact.map { $0.isColour ? $0.value : 7 } ?? 7
        case .clearance(let i): onValue = BallKind.colourOrder[i].value
        }

        // --- Foul detection --------------------------------------------------
        var foulReason: String?
        var penalty = max(4, onValue)

        if let first = events.firstContact {
            if !wasOn.accepts(first) {
                foulReason = "Foul: hit the \(first.name.lowercased()) first"
                penalty = max(penalty, first.value)
            }
        } else {
            foulReason = "Foul: missed the \(wasOn.description.lowercased())"
        }

        for kind in pottedKinds {
            if kind == .cue {
                foulReason = foulReason ?? "Foul: in-off"
                continue
            }
            let legal: Bool
            switch wasOn {
            case .red: legal = kind == .red
            case .anyColour: legal = kind == events.firstContact && pottedKinds.filter({ $0 != .cue }).count == 1
            case .clearance(let i): legal = kind == BallKind.colourOrder[i]
            }
            if !legal {
                foulReason = foulReason ?? "Foul: potted the \(kind.name.lowercased())"
                penalty = max(penalty, kind.value)
            }
        }

        // --- Re-spot colours (always, except in the clearance when legal) -----
        let cuePotted = pottedKinds.contains(.cue)
        if cuePotted {
            physics.cueBall.onTable = true
            physics.cueBall.velocity = .zero
            physics.cueBall.position = SnookerTable.defaultCuePosition
            out.cueBallInHand = true
        }

        if let reason = foulReason {
            out.foul = true
            out.foulPoints = min(7, penalty)
            out.message = "\(reason) — \(out.foulPoints) to opponent"
            scores[opponent] += out.foulPoints

            for b in potted where b.kind.isColour {
                // A foul on the final black ends the frame; otherwise colours go back.
                physics.respot(b)
            }
            if case .clearance(5) = wasOn {
                if scores[0] != scores[1] { finishFrame(&out); return out }
            }
            switch wasOn {
            case .red, .anyColour: ballOn = redsLeft > 0 ? .red : .clearance(0)
            case .clearance: break
            }
            endTurn()
            return out
        }

        // --- Legal shot -----------------------------------------------------------
        let scored = pottedKinds.reduce(0) { $0 + $1.value }
        out.points = scored

        switch wasOn {
        case .red:
            if scored > 0 {
                ballOn = .anyColour
                out.turnContinues = true
                out.message = scored == 1 ? "Red potted — now a colour" : "\(scored) reds potted — now a colour"
            }
        case .anyColour:
            if let b = potted.first {
                physics.respot(b)
                out.turnContinues = true
                out.message = "\(b.kind.name) potted (+\(b.kind.value))"
            }
            ballOn = redsLeft > 0 ? .red : .clearance(0)
        case .clearance(let i):
            if scored > 0 {
                out.turnContinues = true
                out.message = "\(BallKind.colourOrder[i].name) potted (+\(scored))"
                if i == 5 {
                    scores[current] += scored
                    currentBreak += scored
                    highestBreak[current] = max(highestBreak[current], currentBreak)
                    if scores[0] == scores[1] {
                        // Re-spotted black decides a tied frame.
                        physics.respot(potted[0])
                        out.message = "Scores level — re-spotted black!"
                        endTurn()
                        out.cueBallInHand = true
                        return out
                    }
                    finishFrame(&out)
                    return out
                }
                ballOn = .clearance(i + 1)
            }
        }

        if out.turnContinues {
            scores[current] += scored
            currentBreak += scored
            highestBreak[current] = max(highestBreak[current], currentBreak)
        } else {
            out.message = "No score"
            endTurn()
        }
        return out
    }

    private func endTurn() {
        currentBreak = 0
        current = opponent
        if ballOn == .anyColour { ballOn = .red }
    }

    private func finishFrame(_ out: inout ShotOutcome) {
        frameOver = true
        out.frameOver = true
        out.turnContinues = false
    }

    var winner: Int? {
        guard frameOver else { return nil }
        return scores[0] >= scores[1] ? 0 : 1
    }
}
