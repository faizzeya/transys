import CoreGraphics

/// A computer opponent. It looks for the easiest pot using "ghost ball"
/// aiming and, if nothing is on, plays a gentle contact shot on a ball on.
struct ComputerPlayer {
    enum Level: Int { case easy = 0, medium = 1, hard = 2 }

    var level: Level = .medium

    struct Plan {
        var direction: CGVector
        var power: CGFloat
        var spin: CGFloat
        var cuePosition: CGPoint?
    }

    /// Aim error in radians for each level.
    private var aimError: CGFloat {
        switch level {
        case .easy: return 0.030
        case .medium: return 0.012
        case .hard: return 0.004
        }
    }

    func plan(physics: PhysicsEngine, ballOn: BallOn, ballInHand: Bool) -> Plan {
        var positions = [physics.cueBall.position]
        if ballInHand { positions = candidateCuePositions(physics: physics) }

        var best: (score: CGFloat, plan: Plan)?
        for cuePos in positions {
            if let candidate = bestPot(from: cuePos, physics: physics, ballOn: ballOn) {
                if best == nil || candidate.score > best!.score {
                    var p = candidate.plan
                    p.cuePosition = ballInHand ? cuePos : nil
                    best = (candidate.score, p)
                }
            }
        }

        var plan = best?.plan ?? safetyShot(from: positions[0], physics: physics, ballOn: ballOn)
        if ballInHand && plan.cuePosition == nil { plan.cuePosition = positions[0] }

        // Human-like inaccuracy.
        let err = CGFloat.random(in: -aimError...aimError)
        let a = atan2(plan.direction.dy, plan.direction.dx) + err
        plan.direction = CGVector(dx: cos(a), dy: sin(a))
        return plan
    }

    private func bestPot(from cue: CGPoint, physics: PhysicsEngine, ballOn: BallOn) -> (score: CGFloat, plan: Plan)? {
        let r = SnookerTable.ballRadius
        var best: (score: CGFloat, plan: Plan)?
        let targets = physics.balls.filter { $0.onTable && $0.kind != .cue && ballOn.accepts($0.kind) }

        for target in targets {
            for pocket in SnookerTable.pockets {
                let toPocket = (pocket - target.position)
                let dist2 = toPocket.length
                let dir = toPocket.normalized
                let ghost = target.position + dir * (-2 * r)
                let toGhost = ghost - cue
                let dist1 = toGhost.length
                guard dist1 > r else { continue }

                // Cut angle between the cue's line and the object ball's line.
                let cosCut = toGhost.normalized.dot(dir)
                guard cosCut > 0.26 else { continue } // thinner than ~75 degrees

                // Middle pockets only accept fairly straight entries.
                if pocket.x == SnookerTable.playRect.midX && abs(dir.dy) < 0.55 { continue }

                guard physics.pathClear(from: cue, to: ghost, except: [physics.cueBall, target]),
                      physics.pathClear(from: target.position, to: pocket, except: [target]) else { continue }

                var score = cosCut * 3 - (dist1 + dist2) / 900
                if ballOn == .anyColour { score += CGFloat(target.kind.value) * 0.12 }

                // Enough pace to reach the pocket after a cut, with some to spare.
                let decel: CGFloat = 270
                let objectSpeed = sqrt(2 * decel * dist2) * 1.35 + 60
                let contactSpeed = objectSpeed / (cosCut * 0.97)
                let startSpeed = sqrt(contactSpeed * contactSpeed + 2 * decel * dist1)
                let power = min(1, max(0.2, sqrt(max(0, startSpeed - 120) / 1450)))
                let plan = Plan(direction: toGhost.normalized, power: power, spin: -0.15, cuePosition: nil)
                if best == nil || score > best!.score { best = (score, plan) }
            }
        }
        return best
    }

    /// No pot available: roll up to the nearest legal ball.
    private func safetyShot(from cue: CGPoint, physics: PhysicsEngine, ballOn: BallOn) -> Plan {
        let targets = physics.balls.filter { $0.onTable && $0.kind != .cue && ballOn.accepts($0.kind) }
        let clear = targets.filter { physics.pathClear(from: cue, to: $0.position, except: [physics.cueBall, $0]) }
        let pool = clear.isEmpty ? targets : clear
        guard let target = pool.min(by: { $0.position.distance(to: cue) < $1.position.distance(to: cue) }) else {
            return Plan(direction: CGVector(dx: 1, dy: 0), power: 0.4, spin: 0, cuePosition: nil)
        }
        let d = target.position - cue
        return Plan(direction: d.normalized, power: min(0.55, 0.25 + d.length / 3000), spin: 0, cuePosition: nil)
    }

    /// Positions inside the "D" to try when the computer has ball in hand.
    private func candidateCuePositions(physics: PhysicsEngine) -> [CGPoint] {
        let brown = SnookerTable.spot(for: .brown)
        let rD = SnookerTable.dRadius - 4
        var list = [SnookerTable.defaultCuePosition]
        for angle in stride(from: CGFloat.pi / 2, through: 3 * CGFloat.pi / 2, by: CGFloat.pi / 8) {
            for f in [0.4, 0.8] as [CGFloat] {
                list.append(CGPoint(x: brown.x + cos(angle) * rD * f, y: brown.y + sin(angle) * rD * f))
            }
        }
        let free = list.filter { physics.isFree($0, ignoring: physics.cueBall) }
        return free.isEmpty ? [SnookerTable.defaultCuePosition] : free
    }
}
