import CoreGraphics

/// Geometry of the table, in scene points. The scene is 1334 x 750 (landscape).
/// Proportions follow a full-size 12 ft snooker table.
enum SnookerTable {
    static let sceneSize = CGSize(width: 1334, height: 750)

    /// Playing surface (cloth inside the cushions). Ratio 2:1 like a real table.
    static let playRect = CGRect(x: 120, y: 62, width: 1040, height: 520)

    static let ballRadius: CGFloat = 9.5
    static let cushionWidth: CGFloat = 26
    /// Length of rail left open next to each corner pocket.
    static let cornerGap: CGFloat = 24
    /// Half-width of each middle pocket opening.
    static let middleGap: CGFloat = 20
    /// A ball whose centre comes this close to a pocket centre is potted.
    static let pocketCaptureRadius: CGFloat = 18

    static var length: CGFloat { playRect.width }
    static var midY: CGFloat { playRect.midY }
    /// Baulk line is 29 in (0.2065 of the length) from the baulk cushion.
    static var baulkX: CGFloat { playRect.minX + length * 0.2065 }
    /// Radius of the "D" (11.5 in).
    static var dRadius: CGFloat { length * 0.0818 }

    static var defaultCuePosition: CGPoint {
        CGPoint(x: baulkX - dRadius * 0.55, y: midY + dRadius * 0.3)
    }

    /// Four corners first, then the two middle pockets.
    static var pockets: [CGPoint] {
        let r = playRect
        let o: CGFloat = 6
        return [
            CGPoint(x: r.minX - o, y: r.minY - o),
            CGPoint(x: r.maxX + o, y: r.minY - o),
            CGPoint(x: r.minX - o, y: r.maxY + o),
            CGPoint(x: r.maxX + o, y: r.maxY + o),
            CGPoint(x: r.midX, y: r.minY - 10),
            CGPoint(x: r.midX, y: r.maxY + 10)
        ]
    }

    /// Official spot for each colour. The baulk end is on the left.
    static func spot(for kind: BallKind) -> CGPoint {
        switch kind {
        case .yellow: return CGPoint(x: baulkX, y: midY - dRadius)
        case .green:  return CGPoint(x: baulkX, y: midY + dRadius)
        case .brown:  return CGPoint(x: baulkX, y: midY)
        case .blue:   return CGPoint(x: playRect.midX, y: midY)
        case .pink:   return CGPoint(x: playRect.midX + length / 4, y: midY)
        case .black:  return CGPoint(x: playRect.maxX - length * 0.0908, y: midY)
        case .red, .cue: return defaultCuePosition
        }
    }
}
