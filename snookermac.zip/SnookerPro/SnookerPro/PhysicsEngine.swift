import CoreGraphics

/// What happened during one shot, collected while the balls move.
struct ShotEvents {
    /// The first ball the cue ball touched, if any.
    var firstContact: BallKind?
    /// Balls potted during the shot, in the order they dropped.
    var potted: [Ball] = []
    /// Number of ball-on-ball impacts (used for sound).
    var impacts = 0
}

/// A small, deterministic 2D ball physics engine tuned for snooker.
/// SpriteKit's built-in physics is not used because pockets, cushions and
/// rolling friction need precise control.
final class PhysicsEngine {
    private(set) var balls: [Ball] = []
    var events = ShotEvents()

    /// Called whenever something audible happens (impact, cushion, pot).
    var onImpact: ((ImpactKind, CGFloat) -> Void)?

    enum ImpactKind { case ball, cushion, pocket }

    // Tuning constants
    let rollingFriction: CGFloat = 230      // points / s^2
    let linearDamping: CGFloat = 0.12       // fraction of speed lost per second
    let ballRestitution: CGFloat = 0.95
    let cushionRestitution: CGFloat = 0.72
    let stopSpeed: CGFloat = 4
    let substeps = 12

    /// Follow (+) or screw (-) applied to the cue ball, -1...1.
    var cueSpin: CGFloat = 0
    /// Side spin applied to the cue ball, -1 (left) ... 1 (right).
    var cueSide: CGFloat = 0
    private var spinApplied = true
    private var shotDirection = CGVector.zero
    private var shotSpeed: CGFloat = 0

    var cueBall: Ball { balls[0] }
    var isMoving: Bool { balls.contains { $0.onTable && $0.isMoving } }

    init() { reset() }

    /// Racks the balls for a new frame.
    func reset() {
        var list: [Ball] = []
        list.append(Ball(id: 0, kind: .cue, position: SnookerTable.defaultCuePosition))
        for (i, kind) in BallKind.colourOrder.enumerated() {
            list.append(Ball(id: i + 1, kind: kind, position: SnookerTable.spot(for: kind)))
        }
        // Triangle of 15 reds with its apex just behind the pink.
        let r = SnookerTable.ballRadius
        let pink = SnookerTable.spot(for: .pink)
        let apex = CGPoint(x: pink.x + 2 * r + 1.5, y: pink.y)
        let rowStep = (2 * r + 0.4) * 0.866
        var id = 7
        for row in 0..<5 {
            for j in 0...row {
                let y = apex.y + (CGFloat(j) - CGFloat(row) / 2) * (2 * r + 0.4)
                list.append(Ball(id: id, kind: .red, position: CGPoint(x: apex.x + CGFloat(row) * rowStep, y: y)))
                id += 1
            }
        }
        balls = list
        events = ShotEvents()
    }

    /// Strikes the cue ball. `power` is 0...1.
    func shoot(direction: CGVector, power: CGFloat) {
        events = ShotEvents()
        let speed = 120 + 1450 * power * power
        shotDirection = direction.normalized
        shotSpeed = speed
        cueBall.velocity = shotDirection * speed
        spinApplied = false
    }

    /// Advances the simulation by `dt` seconds.
    func step(_ dt: CGFloat) {
        let h = dt / CGFloat(substeps)
        for _ in 0..<substeps {
            integrate(h)
            resolveBallCollisions()
            resolveCushions()
            capturePots()
        }
    }

    // MARK: - Integration

    private func integrate(_ h: CGFloat) {
        for b in balls where b.onTable && b.isMoving {
            b.position = b.position + b.velocity * h
            let speed = b.velocity.length
            var newSpeed = speed - rollingFriction * h - speed * linearDamping * h
            if newSpeed < stopSpeed { newSpeed = 0 }
            b.velocity = newSpeed == 0 ? .zero : b.velocity * (newSpeed / speed)
        }
    }

    // MARK: - Ball to ball

    private func resolveBallCollisions() {
        let minDist = 2 * SnookerTable.ballRadius
        let live = balls.filter { $0.onTable }
        for i in 0..<live.count {
            for j in (i + 1)..<live.count {
                let a = live[i], b = live[j]
                let delta = b.position - a.position
                let dist = delta.length
                guard dist < minDist, dist > 0.0001 else { continue }
                let n = delta * (1 / dist)

                // Separate the overlap evenly.
                let push = (minDist - dist) / 2
                a.position = a.position + n * (-push)
                b.position = b.position + n * push

                // Equal-mass collision along the normal.
                let rel = a.velocity - b.velocity
                let approach = rel.dot(n)
                guard approach > 0 else { continue }
                let impulse = n * (approach * (1 + ballRestitution) / 2)
                a.velocity = a.velocity - impulse
                b.velocity = b.velocity + impulse

                if a.kind == .cue || b.kind == .cue {
                    let other = a.kind == .cue ? b : a
                    if events.firstContact == nil { events.firstContact = other.kind }
                    applySpinIfNeeded()
                }
                events.impacts += 1
                onImpact?(.ball, approach)
            }
        }
    }

    /// Follow / screw / side are applied once, at the cue ball's first impact.
    private func applySpinIfNeeded() {
        guard !spinApplied else { return }
        spinApplied = true
        let carried = shotSpeed * 0.45
        var v = cueBall.velocity + shotDirection * (cueSpin * carried)
        if cueSide != 0 {
            let perpendicular = CGVector(dx: -shotDirection.dy, dy: shotDirection.dx)
            v = v + perpendicular * (-cueSide * carried * 0.25)
        }
        cueBall.velocity = v
    }

    // MARK: - Cushions and pocket jaws

    private func resolveCushions() {
        let rect = SnookerTable.playRect
        let r = SnookerTable.ballRadius
        let cg = SnookerTable.cornerGap
        let mg = SnookerTable.middleGap

        for b in balls where b.onTable {
            let p = b.position
            // Long cushions (bottom and top) have a gap for the middle pocket.
            let onLongRail = (p.x > rect.minX + cg && p.x < rect.midX - mg) ||
                             (p.x > rect.midX + mg && p.x < rect.maxX - cg)
            let onShortRail = p.y > rect.minY + cg && p.y < rect.maxY - cg

            if onLongRail {
                if p.y - r < rect.minY && b.velocity.dy < 0 {
                    b.position.y = rect.minY + r
                    bounce(b, normal: CGVector(dx: 0, dy: 1))
                } else if p.y + r > rect.maxY && b.velocity.dy > 0 {
                    b.position.y = rect.maxY - r
                    bounce(b, normal: CGVector(dx: 0, dy: -1))
                }
            }
            if onShortRail {
                if p.x - r < rect.minX && b.velocity.dx < 0 {
                    b.position.x = rect.minX + r
                    bounce(b, normal: CGVector(dx: 1, dy: 0))
                } else if p.x + r > rect.maxX && b.velocity.dx > 0 {
                    b.position.x = rect.maxX - r
                    bounce(b, normal: CGVector(dx: -1, dy: 0))
                }
            }
            for jaw in Self.jawPoints { collide(b, withPoint: jaw) }
        }
    }

    private func bounce(_ b: Ball, normal n: CGVector) {
        let vn = b.velocity.dot(n)
        guard vn < 0 else { return }
        b.velocity = (b.velocity - n * (vn * (1 + cushionRestitution))) * 0.97
        onImpact?(.cushion, -vn)
    }

    /// The rounded ends of the cushions beside every pocket.
    private static let jawPoints: [CGPoint] = {
        let rect = SnookerTable.playRect
        let cg = SnookerTable.cornerGap
        let mg = SnookerTable.middleGap
        return [
            CGPoint(x: rect.minX + cg, y: rect.minY), CGPoint(x: rect.minX, y: rect.minY + cg),
            CGPoint(x: rect.maxX - cg, y: rect.minY), CGPoint(x: rect.maxX, y: rect.minY + cg),
            CGPoint(x: rect.minX + cg, y: rect.maxY), CGPoint(x: rect.minX, y: rect.maxY - cg),
            CGPoint(x: rect.maxX - cg, y: rect.maxY), CGPoint(x: rect.maxX, y: rect.maxY - cg),
            CGPoint(x: rect.midX - mg, y: rect.minY), CGPoint(x: rect.midX + mg, y: rect.minY),
            CGPoint(x: rect.midX - mg, y: rect.maxY), CGPoint(x: rect.midX + mg, y: rect.maxY)
        ]
    }()

    private func collide(_ b: Ball, withPoint q: CGPoint) {
        let r = SnookerTable.ballRadius
        let delta = b.position - q
        let dist = delta.length
        guard dist < r, dist > 0.0001 else { return }
        let n = delta * (1 / dist)
        b.position = q + n * r
        bounce(b, normal: n)
    }

    // MARK: - Pockets

    private func capturePots() {
        let rect = SnookerTable.playRect
        let r = SnookerTable.ballRadius
        for b in balls where b.onTable {
            let nearPocket = SnookerTable.pockets.contains {
                b.position.distance(to: $0) < SnookerTable.pocketCaptureRadius
            }
            // A ball can only leave the cloth through a pocket mouth.
            let leftCloth = b.position.x < rect.minX - r || b.position.x > rect.maxX + r ||
                            b.position.y < rect.minY - r || b.position.y > rect.maxY + r
            if nearPocket || leftCloth {
                b.onTable = false
                b.velocity = .zero
                events.potted.append(b)
                onImpact?(.pocket, 0)
            }
        }
    }

    // MARK: - Helpers for rules and AI

    /// Puts a potted colour back on its spot, or the nearest free place.
    func respot(_ ball: Ball) {
        ball.velocity = .zero
        ball.onTable = true
        let own = SnookerTable.spot(for: ball.kind)
        if isFree(own, ignoring: ball) { ball.position = own; return }
        for kind in BallKind.colourOrder.reversed() {
            let s = SnookerTable.spot(for: kind)
            if isFree(s, ignoring: ball) { ball.position = s; return }
        }
        var x = own.x
        while x > SnookerTable.playRect.minX + SnookerTable.ballRadius {
            x -= 1
            let p = CGPoint(x: x, y: own.y)
            if isFree(p, ignoring: ball) { ball.position = p; return }
        }
        ball.position = own
    }

    func isFree(_ p: CGPoint, ignoring: Ball? = nil) -> Bool {
        let minDist = 2 * SnookerTable.ballRadius + 0.5
        return !balls.contains { $0.onTable && $0 !== ignoring && $0.position.distance(to: p) < minDist }
    }

    /// True if a ball of radius r can travel from `a` to `b` without touching
    /// any ball other than those listed in `except`.
    func pathClear(from a: CGPoint, to b: CGPoint, except: [Ball]) -> Bool {
        let seg = b - a
        let len2 = seg.dot(seg)
        let minDist = 2 * SnookerTable.ballRadius
        for ball in balls where ball.onTable && !except.contains(where: { $0 === ball }) {
            var t = len2 > 0 ? (ball.position - a).dot(seg) / len2 : 0
            t = max(0, min(1, t))
            let closest = a + seg * t
            if ball.position.distance(to: closest) < minDist { return false }
        }
        return true
    }
}
